#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用真实数据测试波段式上升检测器

该脚本专门用于测试 wave_uptrend_pattern_detector.py 和真实股票数据 sz301209.csv
解决编码问题并进行波段式上升形态识别

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# TSFresh相关导入
try:
    from tsfresh import extract_features, select_features
    from tsfresh.utilities.dataframe_functions import impute
    from tsfresh.feature_extraction import ComprehensiveFCParameters
    TSFRESH_AVAILABLE = True
    print("TSFresh已成功导入")
except ImportError:
    print("警告: TSFresh未安装，将使用传统技术指标分析")
    TSFRESH_AVAILABLE = False

# 机器学习和数据分析
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from scipy import stats
from scipy.signal import find_peaks, argrelextrema

# 可视化
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
plt.rcParams['axes.unicode_minus'] = False


def load_real_stock_data(file_path: str) -> pd.DataFrame:
    """
    加载真实股票数据，处理编码问题
    
    Args:
        file_path: CSV文件路径
    
    Returns:
        处理后的股票数据DataFrame
    """
    print(f"加载真实股票数据: {file_path}")
    
    # 尝试不同的编码方式
    encodings = ['gbk', 'gb2312', 'utf-8', 'utf-8-sig']
    
    for encoding in encodings:
        try:
            print(f"尝试编码: {encoding}")
            df = pd.read_csv(file_path, encoding=encoding)
            print(f"成功使用编码 {encoding} 读取数据")
            print(f"数据形状: {df.shape}")
            print(f"列名: {list(df.columns)[:5]}...")  # 显示前5个列名
            return df
        except Exception as e:
            print(f"编码 {encoding} 失败: {e}")
            continue
    
    raise ValueError("无法使用任何编码读取文件")


def clean_and_prepare_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    清洗和准备股票数据
    
    Args:
        df: 原始数据DataFrame
    
    Returns:
        清洗后的DataFrame
    """
    print("清洗和准备数据...")
    
    # 显示原始数据信息
    print(f"原始数据形状: {df.shape}")
    print("原始列名:")
    for i, col in enumerate(df.columns):
        print(f"{i+1:2d}. {col}")
    
    # 根据列的位置重新命名（因为中文列名可能有问题）
    if len(df.columns) >= 7:
        # 假设列的顺序是：股票代码,股票名称,交易日期,开盘价,最高价,最低价,收盘价,...
        new_columns = {
            df.columns[0]: '代码',
            df.columns[1]: '名称', 
            df.columns[2]: '交易日期',
            df.columns[3]: '开盘价',
            df.columns[4]: '最高价',
            df.columns[5]: '最低价',
            df.columns[6]: '收盘价'
        }
        
        # 如果有更多列，保留原名
        for i, col in enumerate(df.columns):
            if i >= 7:
                new_columns[col] = col
        
        df = df.rename(columns=new_columns)
        print("重新命名后的主要列名:")
        for col in ['代码', '名称', '交易日期', '开盘价', '最高价', '最低价', '收盘价']:
            if col in df.columns:
                print(f"  {col}: {df[col].dtype}")
    
    # 处理日期
    if '交易日期' in df.columns:
        df['交易日期'] = pd.to_datetime(df['交易日期'], errors='coerce')
    
    # 处理价格数据
    price_columns = ['开盘价', '最高价', '最低价', '收盘价']
    for col in price_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # 添加最新价列（使用收盘价）
    if '收盘价' in df.columns:
        df['最新价'] = df['收盘价']
    
    # 计算涨跌幅
    if '最新价' in df.columns:
        df = df.sort_values('交易日期')
        df['涨跌幅'] = df['最新价'].pct_change() * 100
        df['涨跌幅'] = df['涨跌幅'].fillna(0)
    
    # 移除缺失值
    df = df.dropna(subset=['代码', '名称', '最新价'])
    
    print(f"清洗后数据形状: {df.shape}")
    print(f"日期范围: {df['交易日期'].min()} 到 {df['交易日期'].max()}")
    print(f"价格范围: {df['最新价'].min():.2f} 到 {df['最新价'].max():.2f}")
    
    return df


def analyze_with_simple_method(stock_data: pd.DataFrame):
    """
    使用简单方法分析波段式上升
    
    Args:
        stock_data: 股票数据
    """
    print("\n=== 简单方法分析 ===")
    
    # 计算移动平均线
    stock_data['短期均线'] = stock_data['最新价'].rolling(window=5, min_periods=1).mean()
    stock_data['长期均线'] = stock_data['最新价'].rolling(window=20, min_periods=1).mean()
    
    # 分析趋势
    recent_data = stock_data.tail(30)  # 最近30个交易日
    
    # 长期趋势
    long_ma_trend = recent_data['长期均线'].iloc[-1] - recent_data['长期均线'].iloc[0]
    long_trend_pct = (long_ma_trend / recent_data['长期均线'].iloc[0]) * 100
    
    # 价格变化
    price_change = recent_data['最新价'].iloc[-1] - recent_data['最新价'].iloc[0]
    price_change_pct = (price_change / recent_data['最新价'].iloc[0]) * 100
    
    # 波动性分析
    volatility = recent_data['最新价'].std() / recent_data['最新价'].mean() * 100
    
    print(f"股票代码: {stock_data['代码'].iloc[0]}")
    print(f"股票名称: {stock_data['名称'].iloc[0]}")
    print(f"分析周期: 最近30个交易日")
    print(f"长期均线趋势: {long_trend_pct:+.2f}%")
    print(f"价格变化: {price_change_pct:+.2f}%")
    print(f"价格波动率: {volatility:.2f}%")
    
    # 简单判断
    is_uptrend = long_trend_pct > 0 and price_change_pct > 0
    is_moderate_volatility = 5 <= volatility <= 25
    
    print(f"\n简单判断结果:")
    print(f"  上升趋势: {'是' if is_uptrend else '否'}")
    print(f"  适度波动: {'是' if is_moderate_volatility else '否'}")
    print(f"  可能的波段式上升: {'是' if is_uptrend and is_moderate_volatility else '否'}")


def analyze_with_tsfresh(stock_data: pd.DataFrame):
    """
    使用TSFresh进行高级特征提取和分析

    Args:
        stock_data: 股票数据
    """
    print("\n=== TSFresh高级分析 ===")

    if not TSFRESH_AVAILABLE:
        print("TSFresh不可用，跳过高级分析")
        return None

    try:
        # 准备TSFresh格式的数据
        tsfresh_data = prepare_tsfresh_data(stock_data)
        
        if len(tsfresh_data) < 10:
            print("数据点太少，无法进行TSFresh分析")
            return None
        
        print(f"准备TSFresh数据: {len(tsfresh_data)} 个数据点")
        
        # 提取特征
        print("正在提取TSFresh特征...")
        features = extract_features(
            tsfresh_data, 
            column_id='id', 
            column_sort='time',
            default_fc_parameters=ComprehensiveFCParameters()
        )
        
        # 处理缺失值
        features = impute(features)
        
        print(f"提取到 {features.shape[1]} 个特征")
        
        # 分析关键特征
        analyze_key_features(features, stock_data)
        
        return features
        
    except Exception as e:
        print(f"TSFresh分析失败: {e}")
        import traceback
        traceback.print_exc()
        return None


def prepare_tsfresh_data(stock_data: pd.DataFrame) -> pd.DataFrame:
    """
    准备TSFresh格式的数据
    
    Args:
        stock_data: 原始股票数据
    
    Returns:
        TSFresh格式的数据
    """
    # 按日期排序
    stock_data = stock_data.sort_values('交易日期')
    
    # 创建时间序列索引
    tsfresh_data = []
    
    for i, row in stock_data.iterrows():
        tsfresh_data.append({
            'id': 1,  # 单一时间序列
            'time': i,
            'price': row['最新价'],
            'change_pct': row.get('涨跌幅', 0)
        })
    
    return pd.DataFrame(tsfresh_data)


def analyze_key_features(features: pd.DataFrame, stock_data: pd.DataFrame):
    """
    分析关键特征
    
    Args:
        features: TSFresh提取的特征
        stock_data: 原始股票数据
    """
    print("\n=== 关键特征分析 ===")
    
    # 获取价格相关的重要特征
    price_features = [col for col in features.columns if 'price' in col]
    change_features = [col for col in features.columns if 'change_pct' in col]
    
    print(f"价格相关特征: {len(price_features)} 个")
    print(f"涨跌幅相关特征: {len(change_features)} 个")
    
    # 分析趋势特征
    trend_features = [col for col in features.columns if any(keyword in col.lower() for keyword in ['trend', 'slope', 'linear'])]
    print(f"趋势相关特征: {len(trend_features)} 个")
    
    # 分析波动特征
    volatility_features = [col for col in features.columns if any(keyword in col.lower() for keyword in ['std', 'var', 'range'])]
    print(f"波动相关特征: {len(volatility_features)} 个")
    
    # 显示一些关键特征值
    if trend_features:
        print("\n主要趋势特征:")
        for feature in trend_features[:3]:
            value = features[feature].iloc[0]
            print(f"  {feature}: {value:.6f}")
    
    if volatility_features:
        print("\n主要波动特征:")
        for feature in volatility_features[:3]:
            value = features[feature].iloc[0]
            print(f"  {feature}: {value:.6f}")
    
    # 计算波段式上升评分
    wave_score = calculate_wave_uptrend_score(features, stock_data)
    print(f"\nTSFresh波段式上升评分: {wave_score:.3f}")
    
    return wave_score


def calculate_wave_uptrend_score(features: pd.DataFrame, stock_data: pd.DataFrame) -> float:
    """
    基于TSFresh特征计算波段式上升评分
    
    Args:
        features: TSFresh特征
        stock_data: 原始数据
    
    Returns:
        波段式上升评分 (0-1)
    """
    score = 0.0
    
    # 1. 趋势评分 (40%权重)
    trend_features = [col for col in features.columns if 'linear_trend' in col and 'price' in col]
    if trend_features:
        trend_slope = features[trend_features[0]].iloc[0]
        trend_score = min(1.0, max(0.0, trend_slope * 1000))  # 归一化
        score += trend_score * 0.4
    
    # 2. 波动评分 (30%权重)
    std_features = [col for col in features.columns if 'std' in col and 'price' in col]
    if std_features:
        price_std = features[std_features[0]].iloc[0]
        price_mean = stock_data['最新价'].mean()
        volatility_ratio = price_std / price_mean if price_mean > 0 else 0
        # 适度波动得分更高
        volatility_score = 1.0 - abs(volatility_ratio - 0.1) / 0.1 if volatility_ratio <= 0.2 else 0
        volatility_score = max(0, min(1, volatility_score))
        score += volatility_score * 0.3
    
    # 3. 价格变化评分 (30%权重)
    if len(stock_data) > 1:
        total_return = (stock_data['最新价'].iloc[-1] - stock_data['最新价'].iloc[0]) / stock_data['最新价'].iloc[0]
        return_score = min(1.0, max(0.0, total_return * 2))  # 归一化
        score += return_score * 0.3
    
    return score


def visualize_price_trend(stock_data: pd.DataFrame):
    """
    可视化价格趋势
    
    Args:
        stock_data: 股票数据
    """
    print("\n=== 价格趋势可视化 ===")
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # 1. 价格走势图
    ax1 = axes[0, 0]
    ax1.plot(stock_data['交易日期'], stock_data['最新价'], 'b-', linewidth=1, label='收盘价')
    if '短期均线' in stock_data.columns:
        ax1.plot(stock_data['交易日期'], stock_data['短期均线'], 'r--', label='短期均线(5日)')
    if '长期均线' in stock_data.columns:
        ax1.plot(stock_data['交易日期'], stock_data['长期均线'], 'g--', label='长期均线(20日)')
    
    ax1.set_title(f"{stock_data['名称'].iloc[0]} 价格走势")
    ax1.set_xlabel('日期')
    ax1.set_ylabel('价格')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # 2. 涨跌幅分布
    ax2 = axes[0, 1]
    ax2.hist(stock_data['涨跌幅'].dropna(), bins=30, alpha=0.7, color='skyblue')
    ax2.axvline(0, color='red', linestyle='--', alpha=0.7)
    ax2.set_title('涨跌幅分布')
    ax2.set_xlabel('涨跌幅 (%)')
    ax2.set_ylabel('频次')
    ax2.grid(True, alpha=0.3)
    
    # 3. 价格波动分析
    ax3 = axes[1, 0]
    rolling_std = stock_data['最新价'].rolling(window=20).std()
    ax3.plot(stock_data['交易日期'], rolling_std, 'purple', label='20日滚动标准差')
    ax3.set_title('价格波动性')
    ax3.set_xlabel('日期')
    ax3.set_ylabel('标准差')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    
    # 4. 最近30天详细走势
    ax4 = axes[1, 1]
    recent_data = stock_data.tail(30)
    ax4.plot(recent_data['交易日期'], recent_data['最新价'], 'b-', linewidth=2, marker='o', markersize=3)
    ax4.set_title('最近30个交易日走势')
    ax4.set_xlabel('日期')
    ax4.set_ylabel('价格')
    ax4.grid(True, alpha=0.3)
    
    # 旋转日期标签
    for ax in axes.flat:
        for label in ax.get_xticklabels():
            label.set_rotation(45)
    
    plt.tight_layout()
    plt.show()


def main():
    """
    主函数
    """
    print("使用真实数据测试波段式上升检测器")
    print("=" * 50)
    
    # 文件路径
    data_file = "sz301209.csv"
    
    if not Path(data_file).exists():
        print(f"错误: 数据文件 {data_file} 不存在")
        return
    
    try:
        # 1. 加载数据
        stock_data = load_real_stock_data(data_file)
        
        # 2. 清洗数据
        stock_data = clean_and_prepare_data(stock_data)
        
        # 3. 显示数据样本
        print("\n=== 数据样本 ===")
        print(stock_data[['代码', '名称', '交易日期', '最新价', '涨跌幅']].head(10))
        print("...")
        print(stock_data[['代码', '名称', '交易日期', '最新价', '涨跌幅']].tail(5))
        
        # 4. 简单方法分析
        analyze_with_simple_method(stock_data)
        
        # 5. TSFresh高级分析
        tsfresh_features = analyze_with_tsfresh(stock_data)
        
        # 6. 可视化
        visualize_price_trend(stock_data)
        
        # 7. 总结
        print("\n=== 分析总结 ===")
        print(f"数据文件: {data_file}")
        print(f"股票代码: {stock_data['代码'].iloc[0]}")
        print(f"股票名称: {stock_data['名称'].iloc[0]}")
        print(f"数据点数: {len(stock_data)}")
        print(f"时间跨度: {stock_data['交易日期'].min().strftime('%Y-%m-%d')} 到 {stock_data['交易日期'].max().strftime('%Y-%m-%d')}")
        
        if tsfresh_features is not None:
            print(f"\nTSFresh分析结果:")
            print(f"  提取特征数量: {tsfresh_features.shape[1]}")
            print(f"  特征提取成功: 是")
            
            # 重新计算波段式上升评分用于总结
            final_score = calculate_wave_uptrend_score(tsfresh_features, stock_data)
            print(f"  最终波段式上升评分: {final_score:.3f}")
            print(f"  是否波段式上升: {'是' if final_score > 0.6 else '否'}")
        
        print("\n分析完成！")
        
    except Exception as e:
        print(f"分析过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()