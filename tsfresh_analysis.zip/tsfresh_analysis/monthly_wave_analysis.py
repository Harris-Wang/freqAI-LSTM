#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
股票月度波段式上升分析器

专门分析股票的月度表现，识别符合波段式上升理念的可买入区间
特别关注2025-04阶段的投资机会

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
from pathlib import Path
import warnings
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
warnings.filterwarnings('ignore')

# 可视化
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
plt.rcParams['axes.unicode_minus'] = False

# 技术分析
from scipy.signal import find_peaks, argrelextrema
from scipy import stats


class MonthlyWaveAnalyzer:
    """
    月度波段式上升分析器
    
    专门分析股票的月度表现，识别波段式上升的买入时机
    """
    
    def __init__(self, csv_file: str):
        """
        初始化月度波段分析器
        
        Args:
            csv_file: 股票数据CSV文件路径
        """
        self.csv_file = csv_file
        self.stock_data = None
        self.monthly_data = None
        self.analysis_results = None
        
    def load_and_prepare_data(self) -> pd.DataFrame:
        """
        加载并准备股票数据
        
        Returns:
            处理后的股票数据DataFrame
        """
        print(f"加载股票数据: {self.csv_file}")
        
        # 尝试不同编码
        encodings = ['gbk', 'gb2312', 'utf-8', 'utf-8-sig']
        
        for encoding in encodings:
            try:
                df = pd.read_csv(self.csv_file, encoding=encoding)
                print(f"成功使用编码 {encoding} 读取数据")
                break
            except Exception as e:
                continue
        else:
            raise ValueError("无法读取CSV文件")
        
        # 重新命名列
        if len(df.columns) >= 7:
            new_columns = {
                df.columns[0]: '代码',
                df.columns[1]: '名称', 
                df.columns[2]: '交易日期',
                df.columns[3]: '开盘价',
                df.columns[4]: '最高价',
                df.columns[5]: '最低价',
                df.columns[6]: '收盘价'
            }
            df = df.rename(columns=new_columns)
        
        # 数据处理
        df['交易日期'] = pd.to_datetime(df['交易日期'], errors='coerce')
        price_columns = ['开盘价', '最高价', '最低价', '收盘价']
        for col in price_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        df['最新价'] = df['收盘价']
        df = df.sort_values('交易日期')
        df['涨跌幅'] = df['最新价'].pct_change() * 100
        df['涨跌幅'] = df['涨跌幅'].fillna(0)
        
        # 移除缺失值
        df = df.dropna(subset=['代码', '名称', '最新价'])
        
        self.stock_data = df
        print(f"数据加载完成，共 {len(df)} 条记录")
        print(f"时间跨度: {df['交易日期'].min().strftime('%Y-%m-%d')} 到 {df['交易日期'].max().strftime('%Y-%m-%d')}")
        
        return df
    
    def create_monthly_analysis(self) -> pd.DataFrame:
        """
        创建月度分析数据
        
        Returns:
            月度汇总数据DataFrame
        """
        print("\n=== 创建月度分析数据 ===")
        
        # 添加年月列
        self.stock_data['年月'] = self.stock_data['交易日期'].dt.to_period('M')
        
        # 按月汇总
        monthly_stats = []
        
        for period, group in self.stock_data.groupby('年月'):
            group = group.sort_values('交易日期')
            
            # 基本统计
            month_data = {
                '年月': str(period),
                '年': period.year,
                '月': period.month,
                '交易天数': len(group),
                '开盘价': group['开盘价'].iloc[0],
                '收盘价': group['收盘价'].iloc[-1],
                '最高价': group['最高价'].max(),
                '最低价': group['最低价'].min(),
                '月涨跌幅': ((group['收盘价'].iloc[-1] - group['开盘价'].iloc[0]) / group['开盘价'].iloc[0]) * 100,
                '月振幅': ((group['最高价'].max() - group['最低价'].min()) / group['开盘价'].iloc[0]) * 100,
                '平均价格': group['收盘价'].mean(),
                '价格标准差': group['收盘价'].std(),
                '最大单日涨幅': group['涨跌幅'].max(),
                '最大单日跌幅': group['涨跌幅'].min(),
                '上涨天数': (group['涨跌幅'] > 0).sum(),
                '下跌天数': (group['涨跌幅'] < 0).sum(),
                '平盘天数': (group['涨跌幅'] == 0).sum()
            }
            
            # 计算技术指标
            month_data['5日均线_期末'] = group['收盘价'].rolling(5, min_periods=1).mean().iloc[-1]
            month_data['20日均线_期末'] = group['收盘价'].rolling(20, min_periods=1).mean().iloc[-1]
            
            # 波动性指标
            month_data['变异系数'] = (month_data['价格标准差'] / month_data['平均价格']) * 100 if month_data['平均价格'] > 0 else 0
            month_data['胜率'] = (month_data['上涨天数'] / month_data['交易天数']) * 100 if month_data['交易天数'] > 0 else 0
            
            monthly_stats.append(month_data)
        
        self.monthly_data = pd.DataFrame(monthly_stats)
        
        # 计算月度趋势
        self.monthly_data['前月收盘价'] = self.monthly_data['收盘价'].shift(1)
        self.monthly_data['月度趋势'] = self.monthly_data.apply(
            lambda row: '上升' if row['收盘价'] > row['前月收盘价'] else '下降' if row['收盘价'] < row['前月收盘价'] else '平盘',
            axis=1
        )
        
        print(f"月度数据创建完成，共 {len(self.monthly_data)} 个月")
        return self.monthly_data
    
    def analyze_wave_patterns(self) -> Dict:
        """
        分析波段式上升模式
        
        Returns:
            分析结果字典
        """
        print("\n=== 分析波段式上升模式 ===")
        
        results = {
            'wave_months': [],
            'buy_opportunities': [],
            'analysis_summary': {}
        }
        
        # 1. 识别波段式上升月份
        for i, row in self.monthly_data.iterrows():
            wave_score = self._calculate_wave_score(row, i)
            
            if wave_score >= 0.6:  # 波段式上升阈值
                results['wave_months'].append({
                    '年月': row['年月'],
                    '波段评分': wave_score,
                    '月涨跌幅': row['月涨跌幅'],
                    '月振幅': row['月振幅'],
                    '胜率': row['胜率'],
                    '变异系数': row['变异系数']
                })
        
        # 2. 识别买入机会
        results['buy_opportunities'] = self._identify_buy_opportunities()
        
        # 3. 特别分析2025-04
        april_2025_analysis = self._analyze_april_2025()
        results['april_2025'] = april_2025_analysis
        
        # 4. 汇总分析
        results['analysis_summary'] = self._create_analysis_summary(results)
        
        self.analysis_results = results
        return results
    
    def _calculate_wave_score(self, month_row: pd.Series, index: int) -> float:
        """
        计算月度波段式上升评分
        
        Args:
            month_row: 月度数据行
            index: 行索引
        
        Returns:
            波段评分 (0-1)
        """
        score = 0.0
        
        # 1. 月涨跌幅评分 (30%权重)
        if month_row['月涨跌幅'] > 0:
            trend_score = min(1.0, month_row['月涨跌幅'] / 20)  # 20%涨幅为满分
            score += trend_score * 0.3
        
        # 2. 振幅评分 (25%权重) - 适度振幅更好
        amplitude = month_row['月振幅']
        if 10 <= amplitude <= 40:  # 适度振幅区间
            amplitude_score = 1.0 - abs(amplitude - 25) / 15
            score += max(0, amplitude_score) * 0.25
        
        # 3. 胜率评分 (25%权重)
        win_rate = month_row['胜率']
        if win_rate >= 50:
            win_score = min(1.0, (win_rate - 50) / 30)  # 50%以上胜率
            score += win_score * 0.25
        
        # 4. 稳定性评分 (20%权重) - 变异系数适中
        cv = month_row['变异系数']
        if 2 <= cv <= 8:  # 适度变异系数
            stability_score = 1.0 - abs(cv - 5) / 3
            score += max(0, stability_score) * 0.2
        
        return min(1.0, score)
    
    def _identify_buy_opportunities(self) -> List[Dict]:
        """
        识别买入机会
        
        Returns:
            买入机会列表
        """
        opportunities = []
        
        for i in range(1, len(self.monthly_data)):
            current = self.monthly_data.iloc[i]
            previous = self.monthly_data.iloc[i-1]
            
            # 买入信号条件
            conditions = {
                '前月下跌本月上升': previous['月涨跌幅'] < 0 and current['月涨跌幅'] > 0,
                '连续上升': previous['月涨跌幅'] > 0 and current['月涨跌幅'] > 0,
                '振幅适中': 10 <= current['月振幅'] <= 40,
                '胜率较高': current['胜率'] >= 50,
                '价格相对低位': current['收盘价'] < self.monthly_data['收盘价'].quantile(0.7)
            }
            
            # 计算买入评分
            buy_score = sum(conditions.values()) / len(conditions)
            
            if buy_score >= 0.6:  # 买入阈值
                opportunities.append({
                    '年月': current['年月'],
                    '买入评分': buy_score,
                    '买入理由': [k for k, v in conditions.items() if v],
                    '建议买入价': current['最低价'] * 1.02,  # 略高于最低价
                    '目标价': current['收盘价'] * 1.15,  # 15%目标收益
                    '止损价': current['最低价'] * 0.95,  # 5%止损
                    '月涨跌幅': current['月涨跌幅'],
                    '月振幅': current['月振幅']
                })
        
        return opportunities
    
    def _analyze_april_2025(self) -> Dict:
        """
        特别分析2025年4月
        
        Returns:
            2025年4月分析结果
        """
        april_data = self.monthly_data[self.monthly_data['年月'] == '2025-04']
        
        if april_data.empty:
            return {'status': '无2025年4月数据'}
        
        april = april_data.iloc[0]
        
        # 获取前后月份数据用于对比
        march_data = self.monthly_data[self.monthly_data['年月'] == '2025-03']
        may_data = self.monthly_data[self.monthly_data['年月'] == '2025-05']
        
        analysis = {
            'status': '有数据',
            '基本信息': {
                '月涨跌幅': f"{april['月涨跌幅']:.2f}%",
                '月振幅': f"{april['月振幅']:.2f}%",
                '交易天数': april['交易天数'],
                '胜率': f"{april['胜率']:.1f}%",
                '开盘价': april['开盘价'],
                '收盘价': april['收盘价'],
                '最高价': april['最高价'],
                '最低价': april['最低价']
            },
            '波段特征': {},
            '买入建议': {}
        }
        
        # 波段特征分析
        wave_score = self._calculate_wave_score(april, april_data.index[0])
        analysis['波段特征'] = {
            '波段评分': f"{wave_score:.3f}",
            '是否波段式上升': '是' if wave_score >= 0.6 else '否',
            '变异系数': f"{april['变异系数']:.2f}%",
            '趋势方向': april['月度趋势']
        }
        
        # 买入建议
        if wave_score >= 0.6:
            analysis['买入建议'] = {
                '建议': '符合波段式上升，建议买入',
                '最佳买入价': f"{april['最低价'] * 1.02:.2f}",
                '目标价': f"{april['收盘价'] * 1.15:.2f}",
                '止损价': f"{april['最低价'] * 0.95:.2f}",
                '风险评级': '中等'
            }
        else:
            analysis['买入建议'] = {
                '建议': '不符合波段式上升特征，谨慎买入',
                '风险评级': '较高'
            }
        
        # 与前后月对比
        if not march_data.empty:
            march = march_data.iloc[0]
            analysis['与3月对比'] = {
                '涨跌幅变化': f"{april['月涨跌幅'] - march['月涨跌幅']:+.2f}%",
                '振幅变化': f"{april['月振幅'] - march['月振幅']:+.2f}%"
            }
        
        return analysis
    
    def _create_analysis_summary(self, results: Dict) -> Dict:
        """
        创建分析汇总
        
        Args:
            results: 分析结果
        
        Returns:
            汇总信息
        """
        summary = {
            '总月份数': len(self.monthly_data),
            '波段式上升月份数': len(results['wave_months']),
            '买入机会数': len(results['buy_opportunities']),
            '波段式上升比例': f"{len(results['wave_months']) / len(self.monthly_data) * 100:.1f}%",
            '平均月涨跌幅': f"{self.monthly_data['月涨跌幅'].mean():.2f}%",
            '最佳表现月份': None,
            '最差表现月份': None
        }
        
        # 最佳和最差月份
        best_month = self.monthly_data.loc[self.monthly_data['月涨跌幅'].idxmax()]
        worst_month = self.monthly_data.loc[self.monthly_data['月涨跌幅'].idxmin()]
        
        summary['最佳表现月份'] = {
            '年月': best_month['年月'],
            '涨跌幅': f"{best_month['月涨跌幅']:.2f}%"
        }
        
        summary['最差表现月份'] = {
            '年月': worst_month['年月'],
            '涨跌幅': f"{worst_month['月涨跌幅']:.2f}%"
        }
        
        return summary
    
    def visualize_monthly_analysis(self):
        """
        可视化月度分析结果
        """
        print("\n=== 生成可视化图表 ===")
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # 1. 月度涨跌幅趋势
        ax1 = axes[0, 0]
        self.monthly_data['月涨跌幅'].plot(kind='bar', ax=ax1, color=['red' if x < 0 else 'green' for x in self.monthly_data['月涨跌幅']])
        ax1.set_title('月度涨跌幅趋势')
        ax1.set_xlabel('月份')
        ax1.set_ylabel('涨跌幅 (%)')
        ax1.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax1.tick_params(axis='x', rotation=45)
        
        # 2. 月度振幅分析
        ax2 = axes[0, 1]
        self.monthly_data['月振幅'].plot(kind='line', ax=ax2, marker='o', color='blue')
        ax2.set_title('月度振幅变化')
        ax2.set_xlabel('月份')
        ax2.set_ylabel('振幅 (%)')
        ax2.grid(True, alpha=0.3)
        
        # 3. 胜率分布
        ax3 = axes[0, 2]
        self.monthly_data['胜率'].hist(bins=10, ax=ax3, color='skyblue', alpha=0.7)
        ax3.set_title('月度胜率分布')
        ax3.set_xlabel('胜率 (%)')
        ax3.set_ylabel('频次')
        ax3.axvline(x=50, color='red', linestyle='--', label='50%基准线')
        ax3.legend()
        
        # 4. 价格走势与均线
        ax4 = axes[1, 0]
        ax4.plot(range(len(self.monthly_data)), self.monthly_data['收盘价'], 'b-', label='月收盘价', linewidth=2)
        ax4.plot(range(len(self.monthly_data)), self.monthly_data['5日均线_期末'], 'r--', label='5日均线', alpha=0.7)
        ax4.plot(range(len(self.monthly_data)), self.monthly_data['20日均线_期末'], 'g--', label='20日均线', alpha=0.7)
        ax4.set_title('价格走势与均线')
        ax4.set_xlabel('月份')
        ax4.set_ylabel('价格')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # 5. 波段式上升月份标记
        ax5 = axes[1, 1]
        wave_months = [item['年月'] for item in self.analysis_results['wave_months']]
        wave_scores = [item['波段评分'] for item in self.analysis_results['wave_months']]
        
        colors = ['green' if score >= 0.8 else 'orange' if score >= 0.6 else 'red' for score in wave_scores]
        ax5.bar(range(len(wave_months)), wave_scores, color=colors)
        ax5.set_title('波段式上升月份评分')
        ax5.set_xlabel('波段式上升月份')
        ax5.set_ylabel('评分')
        ax5.set_xticks(range(len(wave_months)))
        ax5.set_xticklabels(wave_months, rotation=45)
        ax5.axhline(y=0.6, color='red', linestyle='--', label='阈值线')
        ax5.legend()
        
        # 6. 买入机会时间分布
        ax6 = axes[1, 2]
        buy_months = [item['年月'] for item in self.analysis_results['buy_opportunities']]
        buy_scores = [item['买入评分'] for item in self.analysis_results['buy_opportunities']]
        
        if buy_months:
            ax6.scatter(range(len(buy_months)), buy_scores, c='red', s=100, alpha=0.7)
            ax6.set_title('买入机会分布')
            ax6.set_xlabel('买入机会月份')
            ax6.set_ylabel('买入评分')
            ax6.set_xticks(range(len(buy_months)))
            ax6.set_xticklabels(buy_months, rotation=45)
            ax6.axhline(y=0.6, color='red', linestyle='--', label='买入阈值')
            ax6.legend()
        else:
            ax6.text(0.5, 0.5, '无买入机会', ha='center', va='center', transform=ax6.transAxes, fontsize=14)
            ax6.set_title('买入机会分布')
        
        plt.tight_layout()
        plt.show()
    
    def generate_report(self) -> str:
        """
        生成分析报告
        
        Returns:
            分析报告文本
        """
        if not self.analysis_results:
            return "请先运行分析"
        
        report = []
        report.append("# 股票月度波段式上升分析报告")
        report.append(f"\n## 基本信息")
        report.append(f"- 股票代码: {self.stock_data['代码'].iloc[0]}")
        report.append(f"- 股票名称: {self.stock_data['名称'].iloc[0]}")
        report.append(f"- 分析期间: {self.stock_data['交易日期'].min().strftime('%Y-%m-%d')} 到 {self.stock_data['交易日期'].max().strftime('%Y-%m-%d')}")
        report.append(f"- 总交易日: {len(self.stock_data)} 天")
        report.append(f"- 分析月份: {len(self.monthly_data)} 个月")
        
        # 汇总统计
        summary = self.analysis_results['analysis_summary']
        report.append(f"\n## 汇总统计")
        report.append(f"- 波段式上升月份: {summary['波段式上升月份数']}/{summary['总月份数']} ({summary['波段式上升比例']})")
        report.append(f"- 买入机会: {summary['买入机会数']} 次")
        report.append(f"- 平均月涨跌幅: {summary['平均月涨跌幅']}")
        report.append(f"- 最佳表现: {summary['最佳表现月份']['年月']} ({summary['最佳表现月份']['涨跌幅']})")
        report.append(f"- 最差表现: {summary['最差表现月份']['年月']} ({summary['最差表现月份']['涨跌幅']})")
        
        # 波段式上升月份详情
        if self.analysis_results['wave_months']:
            report.append(f"\n## 波段式上升月份详情")
            for wave in self.analysis_results['wave_months']:
                report.append(f"\n### {wave['年月']}")
                report.append(f"- 波段评分: {wave['波段评分']:.3f}")
                report.append(f"- 月涨跌幅: {wave['月涨跌幅']:.2f}%")
                report.append(f"- 月振幅: {wave['月振幅']:.2f}%")
                report.append(f"- 胜率: {wave['胜率']:.1f}%")
        
        # 买入机会详情
        if self.analysis_results['buy_opportunities']:
            report.append(f"\n## 买入机会详情")
            for buy in self.analysis_results['buy_opportunities']:
                report.append(f"\n### {buy['年月']} - 买入机会")
                report.append(f"- 买入评分: {buy['买入评分']:.3f}")
                report.append(f"- 买入理由: {', '.join(buy['买入理由'])}")
                report.append(f"- 建议买入价: {buy['建议买入价']:.2f}")
                report.append(f"- 目标价: {buy['目标价']:.2f}")
                report.append(f"- 止损价: {buy['止损价']:.2f}")
        
        # 2025年4月特别分析
        april_analysis = self.analysis_results.get('april_2025', {})
        if april_analysis.get('status') == '有数据':
            report.append(f"\n## 2025年4月特别分析")
            basic = april_analysis['基本信息']
            wave = april_analysis['波段特征']
            buy = april_analysis['买入建议']
            
            report.append(f"\n### 基本表现")
            report.append(f"- 月涨跌幅: {basic['月涨跌幅']}")
            report.append(f"- 月振幅: {basic['月振幅']}")
            report.append(f"- 胜率: {basic['胜率']}")
            report.append(f"- 价格区间: {basic['最低价']:.2f} - {basic['最高价']:.2f}")
            
            report.append(f"\n### 波段特征")
            report.append(f"- 波段评分: {wave['波段评分']}")
            report.append(f"- 是否波段式上升: {wave['是否波段式上升']}")
            report.append(f"- 趋势方向: {wave['趋势方向']}")
            
            report.append(f"\n### 投资建议")
            report.append(f"- {buy['建议']}")
            if '最佳买入价' in buy:
                report.append(f"- 建议买入价: {buy['最佳买入价']}")
                report.append(f"- 目标价: {buy['目标价']}")
                report.append(f"- 止损价: {buy['止损价']}")
            report.append(f"- 风险评级: {buy['风险评级']}")
        
        return "\n".join(report)
    
    def run_full_analysis(self):
        """
        运行完整分析流程
        """
        print("开始股票月度波段式上升分析")
        print("=" * 50)
        
        # 1. 加载数据
        self.load_and_prepare_data()
        
        # 2. 创建月度分析
        self.create_monthly_analysis()
        
        # 3. 分析波段模式
        self.analyze_wave_patterns()
        
        # 4. 显示月度数据概览
        print("\n=== 月度数据概览 ===")
        print(self.monthly_data[['年月', '月涨跌幅', '月振幅', '胜率', '月度趋势']].to_string(index=False))
        
        # 5. 显示分析结果
        print("\n=== 分析结果 ===")
        summary = self.analysis_results['analysis_summary']
        print(f"波段式上升月份: {summary['波段式上升月份数']}/{summary['总月份数']} ({summary['波段式上升比例']})")
        print(f"买入机会: {summary['买入机会数']} 次")
        
        # 6. 显示波段式上升月份
        if self.analysis_results['wave_months']:
            print("\n波段式上升月份:")
            for wave in self.analysis_results['wave_months']:
                print(f"  {wave['年月']}: 评分={wave['波段评分']:.3f}, 涨跌幅={wave['月涨跌幅']:.2f}%")
        
        # 7. 显示买入机会
        if self.analysis_results['buy_opportunities']:
            print("\n买入机会:")
            for buy in self.analysis_results['buy_opportunities']:
                print(f"  {buy['年月']}: 评分={buy['买入评分']:.3f}, 建议价={buy['建议买入价']:.2f}")
        
        # 8. 2025年4月分析
        april_analysis = self.analysis_results.get('april_2025', {})
        if april_analysis.get('status') == '有数据':
            print("\n=== 2025年4月特别分析 ===")
            wave = april_analysis['波段特征']
            buy = april_analysis['买入建议']
            print(f"波段评分: {wave['波段评分']}")
            print(f"是否波段式上升: {wave['是否波段式上升']}")
            print(f"投资建议: {buy['建议']}")
        
        # 9. 可视化
        self.visualize_monthly_analysis()
        
        # 10. 生成报告
        report = self.generate_report()
        
        print("\n分析完成！")
        return report


def main():
    """
    主函数
    """
    # 分析sz301209.csv
    analyzer = MonthlyWaveAnalyzer("sz301209.csv")
    
    try:
        # 运行完整分析
        report = analyzer.run_full_analysis()
        
        # 保存报告
        with open("月度波段分析报告.md", "w", encoding="utf-8") as f:
            f.write(report)
        
        print("\n报告已保存到: 月度波段分析报告.md")
        
    except Exception as e:
        print(f"分析过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()