#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
波段式上升股票形态识别模型

该模型专门用于识别具有以下特征的股票：
1. 长期均线逐步向上
2. 短期均线波浪式上涨
3. 低点不断抬升
4. 高点不断抬升

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# TSFresh相关导入
try:
    from tsfresh import extract_features, select_features
    from tsfresh.utilities.dataframe_functions import impute
    from tsfresh.feature_extraction import ComprehensiveFCParameters
    TSFRESH_AVAILABLE = True
except ImportError:
    print("警告: TSFresh未安装，请运行: pip install tsfresh")
    TSFRESH_AVAILABLE = False

# 机器学习和数据分析
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from scipy import stats
from scipy.signal import find_peaks, argrelextrema

# 可视化
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
plt.rcParams['axes.unicode_minus'] = False


class WaveUptrendPatternDetector:
    """
    波段式上升形态检测器
    
    专门识别具有波段式上升特征的股票：
    - 长期趋势向上
    - 短期波动中低点和高点都在抬升
    - 整体呈现波浪式上升形态
    """
    
    def __init__(self, data_dir: str = "data/zt_data", 
                 long_ma_period: int = 20, 
                 short_ma_period: int = 5,
                 min_wave_length: int = 3):
        """
        初始化波段式上升检测器
        
        Args:
            data_dir: 股票数据目录
            long_ma_period: 长期均线周期
            short_ma_period: 短期均线周期
            min_wave_length: 最小波段长度
        """
        self.data_dir = Path(data_dir)
        self.long_ma_period = long_ma_period
        self.short_ma_period = short_ma_period
        self.min_wave_length = min_wave_length
        
        self.stock_data = None
        self.processed_data = None
        self.pattern_features = None
        self.detection_results = None
        
        if not TSFRESH_AVAILABLE:
            print("警告: TSFresh未安装，将使用传统技术指标分析")
    
    def load_and_prepare_data(self, date_range: list = None, 
                            stock_pools: list = None) -> pd.DataFrame:
        """
        加载并准备股票数据
        
        Args:
            date_range: 日期范围
            stock_pools: 股池类型
        
        Returns:
            处理后的股票数据
        """
        print("加载股票数据...")
        
        all_data = []
        
        # 获取所有可用日期
        available_dates = [d.name for d in self.data_dir.iterdir() if d.is_dir()]
        available_dates.sort()
        
        if date_range:
            available_dates = [d for d in available_dates if date_range[0] <= d <= date_range[1]]
        
        if stock_pools is None:
            stock_pools = ['涨停股池', '强势股池', '昨日涨停股池']
        
        print(f"日期范围: {available_dates[0]} 到 {available_dates[-1]}")
        print(f"股池类型: {stock_pools}")
        
        for date_str in available_dates:
            date_dir = self.data_dir / date_str
            
            for pool_type in stock_pools:
                csv_file = date_dir / f"{pool_type}_{date_str}.csv"
                
                if csv_file.exists():
                    try:
                        df = pd.read_csv(csv_file, encoding='utf-8-sig')
                        df['交易日期'] = pd.to_datetime(date_str, format='%Y%m%d')
                        df['股池类型'] = pool_type
                        all_data.append(df)
                    except Exception as e:
                        print(f"读取文件失败: {csv_file}, 错误: {e}")
        
        if not all_data:
            raise ValueError("未找到任何数据文件")
        
        # 合并所有数据
        self.stock_data = pd.concat(all_data, ignore_index=True)
        
        # 数据清洗
        self.stock_data = self._clean_data(self.stock_data)
        
        print(f"数据加载完成，共 {len(self.stock_data)} 条记录")
        print(f"涵盖 {len(self.stock_data['代码'].unique())} 只股票")
        print(f"时间跨度: {len(available_dates)} 个交易日")
        
        return self.stock_data
    
    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        清洗股票数据
        
        Args:
            df: 原始数据DataFrame
        
        Returns:
            清洗后的DataFrame
        """
        # 移除百分号并转换为数值
        percentage_columns = ['涨跌幅', '换手率']
        for col in percentage_columns:
            if col in df.columns:
                df[col] = df[col].str.replace('%', '').astype(float)
        
        # 处理价格字段
        if '最新价' in df.columns:
            df['最新价'] = pd.to_numeric(df['最新价'], errors='coerce')
        
        # 处理成交额
        if '成交额' in df.columns:
            df['成交额_万元'] = df['成交额'].apply(self._parse_amount)
        
        # 移除缺失值
        df = df.dropna(subset=['代码', '名称', '最新价', '涨跌幅'])
        
        return df
    
    def _parse_amount(self, amount_str: str) -> float:
        """
        解析成交额字符串
        
        Args:
            amount_str: 成交额字符串
        
        Returns:
            成交额数值（万元）
        """
        if pd.isna(amount_str):
            return np.nan
        
        amount_str = str(amount_str).strip()
        
        if '万' in amount_str:
            return float(amount_str.replace('万', ''))
        elif '亿' in amount_str:
            return float(amount_str.replace('亿', '')) * 10000
        else:
            try:
                return float(amount_str)
            except:
                return np.nan
    
    def calculate_technical_indicators(self) -> pd.DataFrame:
        """
        计算技术指标
        
        Returns:
            包含技术指标的DataFrame
        """
        print("计算技术指标...")
        
        processed_stocks = []
        
        for stock_code in self.stock_data['代码'].unique():
            stock_subset = self.stock_data[self.stock_data['代码'] == stock_code].copy()
            stock_subset = stock_subset.sort_values('交易日期')
            
            if len(stock_subset) < self.long_ma_period:
                continue  # 数据不足，跳过
            
            # 计算移动平均线
            stock_subset['短期均线'] = stock_subset['最新价'].rolling(
                window=self.short_ma_period, min_periods=1).mean()
            stock_subset['长期均线'] = stock_subset['最新价'].rolling(
                window=self.long_ma_period, min_periods=1).mean()
            
            # 计算均线斜率（趋势方向）
            stock_subset['长期均线斜率'] = stock_subset['长期均线'].diff()
            stock_subset['短期均线斜率'] = stock_subset['短期均线'].diff()
            
            # 计算价格相对于均线的位置
            stock_subset['价格相对长期均线'] = (stock_subset['最新价'] - stock_subset['长期均线']) / stock_subset['长期均线'] * 100
            stock_subset['价格相对短期均线'] = (stock_subset['最新价'] - stock_subset['短期均线']) / stock_subset['短期均线'] * 100
            
            # 计算波动率
            stock_subset['价格波动率'] = stock_subset['最新价'].rolling(window=5).std()
            stock_subset['涨跌幅波动率'] = stock_subset['涨跌幅'].rolling(window=5).std()
            
            processed_stocks.append(stock_subset)
        
        self.processed_data = pd.concat(processed_stocks, ignore_index=True)
        
        print(f"技术指标计算完成，处理了 {len(self.processed_data['代码'].unique())} 只股票")
        
        return self.processed_data
    
    def detect_wave_patterns(self) -> pd.DataFrame:
        """
        检测波段式上升形态
        
        Returns:
            包含形态检测结果的DataFrame
        """
        print("检测波段式上升形态...")
        
        pattern_results = []
        
        for stock_code in self.processed_data['代码'].unique():
            stock_data = self.processed_data[self.processed_data['代码'] == stock_code].copy()
            stock_data = stock_data.sort_values('交易日期')
            
            if len(stock_data) < self.long_ma_period:
                continue
            
            # 分析长期趋势
            long_trend_score = self._analyze_long_term_trend(stock_data)
            
            # 分析波段特征
            wave_pattern_score = self._analyze_wave_pattern(stock_data)
            
            # 分析高低点抬升
            elevation_score = self._analyze_elevation_pattern(stock_data)
            
            # 综合评分
            total_score = (long_trend_score * 0.4 + 
                          wave_pattern_score * 0.3 + 
                          elevation_score * 0.3)
            
            # 判断是否为波段式上升形态
            is_wave_uptrend = total_score >= 0.6  # 阈值可调整
            
            pattern_results.append({
                '代码': stock_code,
                '名称': stock_data['名称'].iloc[0],
                '长期趋势评分': long_trend_score,
                '波段形态评分': wave_pattern_score,
                '抬升形态评分': elevation_score,
                '综合评分': total_score,
                '是否波段式上升': is_wave_uptrend,
                '最新价': stock_data['最新价'].iloc[-1],
                '最新涨跌幅': stock_data['涨跌幅'].iloc[-1],
                '数据点数量': len(stock_data)
            })
        
        self.detection_results = pd.DataFrame(pattern_results)
        
        # 按综合评分排序
        self.detection_results = self.detection_results.sort_values('综合评分', ascending=False)
        
        wave_uptrend_count = len(self.detection_results[self.detection_results['是否波段式上升']])
        print(f"形态检测完成，发现 {wave_uptrend_count} 只波段式上升股票")
        
        return self.detection_results
    
    def _analyze_long_term_trend(self, stock_data: pd.DataFrame) -> float:
        """
        分析长期趋势
        
        Args:
            stock_data: 单只股票的数据
        
        Returns:
            长期趋势评分 (0-1)
        """
        # 计算长期均线的整体斜率
        long_ma_values = stock_data['长期均线'].dropna()
        
        if len(long_ma_values) < 5:
            return 0.0
        
        # 使用线性回归计算趋势
        x = np.arange(len(long_ma_values))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, long_ma_values)
        
        # 标准化斜率
        normalized_slope = slope / long_ma_values.mean() * 100
        
        # 评分：正斜率得分高，负斜率得分低
        if normalized_slope > 0.5:  # 明显上升趋势
            trend_score = min(1.0, normalized_slope / 2.0)
        elif normalized_slope > 0:  # 轻微上升趋势
            trend_score = 0.3 + normalized_slope * 0.4
        else:  # 下降或平稳趋势
            trend_score = 0.0
        
        # 考虑R²值，趋势越明显得分越高
        r_squared = r_value ** 2
        trend_score *= r_squared
        
        return min(1.0, max(0.0, trend_score))
    
    def _analyze_wave_pattern(self, stock_data: pd.DataFrame) -> float:
        """
        分析波段形态
        
        Args:
            stock_data: 单只股票的数据
        
        Returns:
            波段形态评分 (0-1)
        """
        prices = stock_data['最新价'].values
        
        if len(prices) < 10:
            return 0.0
        
        # 寻找局部极值点
        local_maxima = argrelextrema(prices, np.greater, order=2)[0]
        local_minima = argrelextrema(prices, np.less, order=2)[0]
        
        # 至少需要2个波峰和2个波谷
        if len(local_maxima) < 2 or len(local_minima) < 2:
            return 0.0
        
        # 计算波段特征
        wave_score = 0.0
        
        # 1. 波段数量评分（适中的波段数量得分高）
        total_waves = len(local_maxima) + len(local_minima)
        optimal_waves = len(prices) // 5  # 理想波段数量
        wave_count_score = 1.0 - abs(total_waves - optimal_waves) / optimal_waves
        wave_score += max(0.0, wave_count_score) * 0.3
        
        # 2. 波段规律性评分
        if len(local_maxima) >= 2:
            # 计算波峰间距的标准差，间距越规律得分越高
            peak_intervals = np.diff(local_maxima)
            if len(peak_intervals) > 1:
                interval_cv = np.std(peak_intervals) / np.mean(peak_intervals)
                regularity_score = max(0.0, 1.0 - interval_cv)
                wave_score += regularity_score * 0.3
        
        # 3. 波动幅度评分（适中的波动幅度）
        price_volatility = np.std(prices) / np.mean(prices)
        if 0.05 <= price_volatility <= 0.3:  # 5%-30%的波动率较理想
            volatility_score = 1.0 - abs(price_volatility - 0.15) / 0.15
            wave_score += volatility_score * 0.4
        
        return min(1.0, max(0.0, wave_score))
    
    def _analyze_elevation_pattern(self, stock_data: pd.DataFrame) -> float:
        """
        分析高低点抬升形态
        
        Args:
            stock_data: 单只股票的数据
        
        Returns:
            抬升形态评分 (0-1)
        """
        prices = stock_data['最新价'].values
        
        if len(prices) < 10:
            return 0.0
        
        # 寻找局部极值点
        local_maxima_idx = argrelextrema(prices, np.greater, order=2)[0]
        local_minima_idx = argrelextrema(prices, np.less, order=2)[0]
        
        elevation_score = 0.0
        
        # 分析低点抬升
        if len(local_minima_idx) >= 3:
            minima_values = prices[local_minima_idx]
            
            # 计算低点趋势
            x = np.arange(len(minima_values))
            slope_min, _, r_value_min, _, _ = stats.linregress(x, minima_values)
            
            # 低点上升趋势评分
            if slope_min > 0:
                min_trend_score = min(1.0, slope_min / np.mean(minima_values) * 50)
                min_trend_score *= (r_value_min ** 2)  # 考虑趋势的显著性
                elevation_score += min_trend_score * 0.5
        
        # 分析高点抬升
        if len(local_maxima_idx) >= 3:
            maxima_values = prices[local_maxima_idx]
            
            # 计算高点趋势
            x = np.arange(len(maxima_values))
            slope_max, _, r_value_max, _, _ = stats.linregress(x, maxima_values)
            
            # 高点上升趋势评分
            if slope_max > 0:
                max_trend_score = min(1.0, slope_max / np.mean(maxima_values) * 50)
                max_trend_score *= (r_value_max ** 2)  # 考虑趋势的显著性
                elevation_score += max_trend_score * 0.5
        
        return min(1.0, max(0.0, elevation_score))
    
    def extract_tsfresh_features(self) -> pd.DataFrame:
        """
        使用TSFresh提取高级特征
        
        Returns:
            TSFresh特征DataFrame
        """
        if not TSFRESH_AVAILABLE:
            print("TSFresh不可用，跳过高级特征提取")
            return None
        
        print("使用TSFresh提取高级特征...")
        
        # 准备TSFresh数据格式
        tsfresh_data = []
        
        for stock_code in self.processed_data['代码'].unique():
            stock_subset = self.processed_data[self.processed_data['代码'] == stock_code].copy()
            stock_subset = stock_subset.sort_values('交易日期')
            
            if len(stock_subset) < 5:
                continue
            
            # 为每个指标创建时间序列
            metrics = ['最新价', '涨跌幅', '短期均线', '长期均线']
            
            for metric in metrics:
                if metric in stock_subset.columns:
                    for idx, (_, row) in enumerate(stock_subset.iterrows()):
                        if pd.notna(row[metric]):
                            tsfresh_data.append({
                                'id': f"{stock_code}_{metric}",
                                'time': idx,
                                'value': row[metric]
                            })
        
        if not tsfresh_data:
            return None
        
        tsfresh_df = pd.DataFrame(tsfresh_data)
        
        # 提取特征
        features = extract_features(
            tsfresh_df,
            column_id='id',
            column_sort='time',
            column_value='value',
            default_fc_parameters=ComprehensiveFCParameters(),
            n_jobs=1
        )
        
        # 处理缺失值
        impute(features)
        
        self.pattern_features = features
        
        print(f"TSFresh特征提取完成，共提取 {features.shape[1]} 个特征")
        
        return features
    
    def visualize_detection_results(self, top_n: int = 10, save_path: str = None):
        """
        可视化检测结果
        
        Args:
            top_n: 显示前N只股票
            save_path: 保存路径
        """
        if self.detection_results is None:
            print("请先运行形态检测")
            return
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # 1. 综合评分分布
        axes[0, 0].hist(self.detection_results['综合评分'], bins=20, alpha=0.7, color='skyblue')
        axes[0, 0].axvline(0.6, color='red', linestyle='--', label='阈值线')
        axes[0, 0].set_xlabel('综合评分')
        axes[0, 0].set_ylabel('股票数量')
        axes[0, 0].set_title('综合评分分布')
        axes[0, 0].legend()
        
        # 2. 各项评分对比
        top_stocks = self.detection_results.head(top_n)
        score_columns = ['长期趋势评分', '波段形态评分', '抬升形态评分']
        
        x = np.arange(len(top_stocks))
        width = 0.25
        
        for i, col in enumerate(score_columns):
            axes[0, 1].bar(x + i*width, top_stocks[col], width, 
                          label=col, alpha=0.8)
        
        axes[0, 1].set_xlabel('股票排名')
        axes[0, 1].set_ylabel('评分')
        axes[0, 1].set_title(f'前{top_n}只股票各项评分对比')
        axes[0, 1].set_xticks(x + width)
        axes[0, 1].set_xticklabels([f'{i+1}' for i in range(len(top_stocks))])
        axes[0, 1].legend()
        
        # 3. 波段式上升股票占比
        wave_count = len(self.detection_results[self.detection_results['是否波段式上升']])
        total_count = len(self.detection_results)
        
        labels = ['波段式上升', '其他形态']
        sizes = [wave_count, total_count - wave_count]
        colors = ['lightgreen', 'lightcoral']
        
        axes[0, 2].pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
        axes[0, 2].set_title('股票形态分布')
        
        # 4. 评分相关性热力图
        score_corr = self.detection_results[score_columns + ['综合评分']].corr()
        sns.heatmap(score_corr, annot=True, cmap='coolwarm', center=0, 
                   ax=axes[1, 0], fmt='.2f')
        axes[1, 0].set_title('评分相关性')
        
        # 5. 前10只股票详细信息
        top_wave_stocks = self.detection_results[
            self.detection_results['是否波段式上升']
        ].head(10)
        
        if len(top_wave_stocks) > 0:
            y_pos = np.arange(len(top_wave_stocks))
            axes[1, 1].barh(y_pos, top_wave_stocks['综合评分'], alpha=0.7, color='green')
            axes[1, 1].set_yticks(y_pos)
            axes[1, 1].set_yticklabels(top_wave_stocks['代码'])
            axes[1, 1].set_xlabel('综合评分')
            axes[1, 1].set_title('波段式上升股票排名')
            
            # 添加股票名称
            for i, (idx, row) in enumerate(top_wave_stocks.iterrows()):
                axes[1, 1].text(row['综合评分'] + 0.01, i, 
                               f"{row['名称'][:4]}", 
                               va='center', fontsize=8)
        
        # 6. 评分散点图
        scatter_data = self.detection_results
        colors = ['red' if x else 'blue' for x in scatter_data['是否波段式上升']]
        
        axes[1, 2].scatter(scatter_data['长期趋势评分'], 
                          scatter_data['抬升形态评分'],
                          c=colors, alpha=0.6)
        axes[1, 2].set_xlabel('长期趋势评分')
        axes[1, 2].set_ylabel('抬升形态评分')
        axes[1, 2].set_title('趋势vs抬升评分分布')
        
        # 添加图例
        red_patch = plt.Line2D([0], [0], marker='o', color='w', 
                              markerfacecolor='red', markersize=8, label='波段式上升')
        blue_patch = plt.Line2D([0], [0], marker='o', color='w', 
                               markerfacecolor='blue', markersize=8, label='其他形态')
        axes[1, 2].legend(handles=[red_patch, blue_patch])
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"图表已保存到: {save_path}")
        
        plt.show()
    
    def generate_detection_report(self) -> str:
        """
        生成检测报告
        
        Returns:
            报告文本
        """
        if self.detection_results is None:
            return "请先运行形态检测"
        
        report = []
        report.append("=" * 60)
        report.append("波段式上升股票形态检测报告")
        report.append("=" * 60)
        report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # 检测概况
        total_stocks = len(self.detection_results)
        wave_stocks = len(self.detection_results[self.detection_results['是否波段式上升']])
        
        report.append("## 检测概况")
        report.append(f"- 分析股票总数: {total_stocks}")
        report.append(f"- 波段式上升股票: {wave_stocks}")
        report.append(f"- 检出率: {wave_stocks/total_stocks*100:.1f}%")
        report.append("")
        
        # 评分统计
        report.append("## 评分统计")
        score_stats = self.detection_results[['长期趋势评分', '波段形态评分', '抬升形态评分', '综合评分']].describe()
        
        for col in score_stats.columns:
            report.append(f"### {col}")
            report.append(f"- 平均值: {score_stats.loc['mean', col]:.3f}")
            report.append(f"- 标准差: {score_stats.loc['std', col]:.3f}")
            report.append(f"- 最大值: {score_stats.loc['max', col]:.3f}")
            report.append("")
        
        # 波段式上升股票详情
        wave_uptrend_stocks = self.detection_results[
            self.detection_results['是否波段式上升']
        ].head(20)
        
        if len(wave_uptrend_stocks) > 0:
            report.append("## 波段式上升股票排名 (前20名)")
            report.append("| 排名 | 代码 | 名称 | 综合评分 | 趋势评分 | 波段评分 | 抬升评分 | 最新价 | 涨跌幅 |")
            report.append("|------|------|------|----------|----------|----------|----------|--------|--------|")
            
            for i, (_, row) in enumerate(wave_uptrend_stocks.iterrows(), 1):
                report.append(
                    f"| {i:2d} | {row['代码']} | {row['名称'][:6]} | "
                    f"{row['综合评分']:.3f} | {row['长期趋势评分']:.3f} | "
                    f"{row['波段形态评分']:.3f} | {row['抬升形态评分']:.3f} | "
                    f"{row['最新价']:.2f} | {row['最新涨跌幅']:.2f}% |"
                )
        
        report.append("")
        
        # 模型参数
        report.append("## 模型参数")
        report.append(f"- 长期均线周期: {self.long_ma_period}")
        report.append(f"- 短期均线周期: {self.short_ma_period}")
        report.append(f"- 最小波段长度: {self.min_wave_length}")
        report.append(f"- 检测阈值: 0.6")
        report.append("")
        
        # 形态特征说明
        report.append("## 波段式上升形态特征")
        report.append("1. **长期趋势向上**: 长期均线呈现明显的上升趋势")
        report.append("2. **波段式运行**: 价格呈现规律性的波动，有明显的波峰和波谷")
        report.append("3. **低点抬升**: 每次回调的低点都比前一次高")
        report.append("4. **高点抬升**: 每次上涨的高点都比前一次高")
        report.append("5. **整体向上**: 在波动中保持整体上升的趋势")
        report.append("")
        
        # 投资建议
        report.append("## 投资建议")
        report.append("1. **关注高评分股票**: 综合评分0.8以上的股票值得重点关注")
        report.append("2. **结合基本面**: 技术形态需要配合基本面分析")
        report.append("3. **分批建仓**: 波段式上升适合分批建仓策略")
        report.append("4. **设置止损**: 跌破重要支撑位及时止损")
        report.append("5. **动态跟踪**: 定期更新分析，跟踪形态变化")
        report.append("")
        
        # 风险提示
        report.append("## 风险提示")
        report.append("1. 技术分析存在滞后性，不能保证未来表现")
        report.append("2. 市场环境变化可能导致形态失效")
        report.append("3. 建议结合多种分析方法综合判断")
        report.append("4. 投资有风险，决策需谨慎")
        
        return "\n".join(report)
    
    def save_results(self, output_dir: str = "output"):
        """
        保存检测结果
        
        Args:
            output_dir: 输出目录
        """
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # 保存检测结果
        if self.detection_results is not None:
            results_file = output_path / f"wave_uptrend_detection_{timestamp}.csv"
            self.detection_results.to_csv(results_file, index=False, encoding='utf-8-sig')
            print(f"检测结果已保存到: {results_file}")
        
        # 保存报告
        report = self.generate_detection_report()
        report_file = output_path / f"wave_uptrend_report_{timestamp}.txt"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"检测报告已保存到: {report_file}")
        
        # 保存可视化图表
        chart_file = output_path / f"wave_uptrend_charts_{timestamp}.png"
        self.visualize_detection_results(save_path=chart_file)


def main():
    """
    主函数 - 演示波段式上升形态检测
    """
    print("波段式上升股票形态检测器")
    print("=" * 50)
    
    try:
        # 创建检测器实例
        detector = WaveUptrendPatternDetector(
            data_dir="data/zt_data",
            long_ma_period=20,
            short_ma_period=5,
            min_wave_length=3
        )
        
        # 加载数据
        stock_data = detector.load_and_prepare_data(
            date_range=['20250715', '20250721'],
            stock_pools=['涨停股池', '强势股池', '昨日涨停股池']
        )
        
        print("\n数据样本:")
        print(stock_data[['代码', '名称', '最新价', '涨跌幅', '交易日期']].head())
        
        # 计算技术指标
        processed_data = detector.calculate_technical_indicators()
        
        print("\n技术指标样本:")
        print(processed_data[['代码', '最新价', '短期均线', '长期均线', '长期均线斜率']].head())
        
        # 检测波段式上升形态
        detection_results = detector.detect_wave_patterns()
        
        print("\n检测结果概览:")
        print(f"总股票数: {len(detection_results)}")
        print(f"波段式上升股票: {len(detection_results[detection_results['是否波段式上升']])}")
        
        print("\n前10名波段式上升股票:")
        top_wave_stocks = detection_results[detection_results['是否波段式上升']].head(10)
        if len(top_wave_stocks) > 0:
            print(top_wave_stocks[['代码', '名称', '综合评分', '长期趋势评分', 
                                 '波段形态评分', '抬升形态评分']].to_string(index=False))
        else:
            print("未发现符合条件的波段式上升股票")
        
        # 提取TSFresh特征（可选）
        if TSFRESH_AVAILABLE:
            print("\n提取TSFresh高级特征...")
            tsfresh_features = detector.extract_tsfresh_features()
            if tsfresh_features is not None:
                print(f"TSFresh特征矩阵形状: {tsfresh_features.shape}")
        
        # 可视化结果
        print("\n生成可视化图表...")
        detector.visualize_detection_results(top_n=10)
        
        # 生成报告
        print("\n生成检测报告...")
        report = detector.generate_detection_report()
        print("\n=== 报告摘要 ===")
        print(report[:1500] + "..." if len(report) > 1500 else report)
        
        # 保存结果
        detector.save_results()
        
        print("\n=== 分析完成 ===")
        print("✓ 成功加载和处理股票数据")
        print("✓ 成功计算技术指标")
        print("✓ 成功检测波段式上升形态")
        print("✓ 成功生成可视化图表")
        print("✓ 成功生成检测报告")
        
    except Exception as e:
        print(f"\n❌ 检测过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()