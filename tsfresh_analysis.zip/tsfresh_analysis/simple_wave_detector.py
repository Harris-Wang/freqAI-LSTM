#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化版波段式上升检测器

快速演示如何识别波段式上升的股票形态：
- 长期均线向上
- 短期波动中低点和高点抬升
- 整体呈波浪式上升

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from scipy.signal import argrelextrema
import warnings
warnings.filterwarnings('ignore')

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class SimpleWaveDetector:
    """
    简化版波段式上升检测器
    
    专注于核心的波段式上升特征识别
    """
    
    def __init__(self, long_period=20, short_period=5):
        """
        初始化检测器
        
        Args:
            long_period: 长期均线周期
            short_period: 短期均线周期
        """
        self.long_period = long_period
        self.short_period = short_period
    
    def create_sample_data(self, n_stocks=5, n_days=30):
        """
        创建示例股票数据
        
        Args:
            n_stocks: 股票数量
            n_days: 天数
        
        Returns:
            示例数据DataFrame
        """
        print(f"创建 {n_stocks} 只股票 {n_days} 天的示例数据...")
        
        data = []
        
        for i in range(n_stocks):
            stock_code = f"00000{i+1}"
            stock_name = f"测试股票{i+1}"
            
            # 生成不同类型的价格走势
            if i == 0:  # 波段式上升
                prices = self._generate_wave_uptrend(n_days, base_price=20)
            elif i == 1:  # 单调上升
                prices = self._generate_monotonic_uptrend(n_days, base_price=15)
            elif i == 2:  # 震荡走势
                prices = self._generate_sideways(n_days, base_price=25)
            elif i == 3:  # 下降趋势
                prices = self._generate_downtrend(n_days, base_price=30)
            else:  # 随机走势
                prices = self._generate_random_walk(n_days, base_price=18)
            
            for day in range(n_days):
                data.append({
                    '代码': stock_code,
                    '名称': stock_name,
                    '交易日期': pd.Timestamp('2025-01-01') + pd.Timedelta(days=day),
                    '最新价': round(prices[day], 2),
                    '涨跌幅': round((prices[day] / prices[day-1] - 1) * 100, 2) if day > 0 else 0
                })
        
        return pd.DataFrame(data)
    
    def _generate_wave_uptrend(self, n_days, base_price=20):
        """
        生成波段式上升价格序列
        
        Args:
            n_days: 天数
            base_price: 基础价格
        
        Returns:
            价格序列
        """
        prices = [base_price]
        
        # 设置随机种子确保可重现的波段式上升
        np.random.seed(42)
        
        for i in range(1, n_days):
            # 强化上升趋势
            trend_factor = 1 + 0.008 * i  # 更强的趋势
            
            # 波段特征：正弦波 + 小幅随机波动
            wave_cycle = 2 * np.pi * i / 8  # 8天一个周期
            wave_component = 0.03 * np.sin(wave_cycle)  # 3%的波动幅度
            noise = 0.01 * np.random.normal()  # 1%的随机噪声
            
            # 确保整体向上，低点和高点都抬升
            daily_factor = trend_factor * (1 + wave_component + noise)
            new_price = base_price * daily_factor
            
            # 防止过度下跌，确保波段特征
            if new_price < prices[-1] * 0.98:  # 最多下跌2%
                new_price = prices[-1] * (0.98 + 0.005 * np.random.random())
            
            prices.append(new_price)
        
        return prices
    
    def _generate_monotonic_uptrend(self, n_days, base_price=15):
        """
        生成单调上升价格序列
        
        Args:
            n_days: 天数
            base_price: 基础价格
        
        Returns:
            价格序列
        """
        growth_rate = 0.015  # 每日增长率
        prices = [base_price]
        
        for i in range(1, n_days):
            noise = np.random.normal(0, 0.01)
            new_price = prices[-1] * (1 + growth_rate + noise)
            prices.append(new_price)
        
        return prices
    
    def _generate_sideways(self, n_days, base_price=25):
        """
        生成震荡走势价格序列
        
        Args:
            n_days: 天数
            base_price: 基础价格
        
        Returns:
            价格序列
        """
        prices = [base_price]
        
        for i in range(1, n_days):
            change = np.random.normal(0, 0.02)
            new_price = base_price * (1 + change)
            prices.append(new_price)
        
        return prices
    
    def _generate_downtrend(self, n_days, base_price=30):
        """
        生成下降趋势价格序列
        
        Args:
            n_days: 天数
            base_price: 基础价格
        
        Returns:
            价格序列
        """
        decline_rate = -0.01  # 每日下降率
        prices = [base_price]
        
        for i in range(1, n_days):
            noise = np.random.normal(0, 0.015)
            new_price = prices[-1] * (1 + decline_rate + noise)
            prices.append(new_price)
        
        return prices
    
    def _generate_random_walk(self, n_days, base_price=18):
        """
        生成随机游走价格序列
        
        Args:
            n_days: 天数
            base_price: 基础价格
        
        Returns:
            价格序列
        """
        prices = [base_price]
        
        for i in range(1, n_days):
            change = np.random.normal(0, 0.025)
            new_price = prices[-1] * (1 + change)
            prices.append(max(new_price, base_price * 0.5))  # 防止价格过低
        
        return prices
    
    def calculate_indicators(self, stock_data):
        """
        计算技术指标
        
        Args:
            stock_data: 股票数据
        
        Returns:
            包含指标的数据
        """
        print("计算技术指标...")
        
        result_data = []
        
        for stock_code in stock_data['代码'].unique():
            stock_subset = stock_data[stock_data['代码'] == stock_code].copy()
            stock_subset = stock_subset.sort_values('交易日期')
            
            # 计算移动平均线
            stock_subset['短期均线'] = stock_subset['最新价'].rolling(
                window=self.short_period, min_periods=1).mean()
            stock_subset['长期均线'] = stock_subset['最新价'].rolling(
                window=self.long_period, min_periods=1).mean()
            
            # 计算均线斜率
            stock_subset['长期均线斜率'] = stock_subset['长期均线'].diff()
            
            result_data.append(stock_subset)
        
        return pd.concat(result_data, ignore_index=True)
    
    def detect_wave_pattern(self, stock_data):
        """
        检测波段式上升形态
        
        Args:
            stock_data: 包含技术指标的股票数据
        
        Returns:
            检测结果
        """
        print("检测波段式上升形态...")
        
        results = []
        
        for stock_code in stock_data['代码'].unique():
            stock_subset = stock_data[stock_data['代码'] == stock_code].copy()
            stock_subset = stock_subset.sort_values('交易日期')
            
            if len(stock_subset) < self.long_period:
                continue
            
            # 1. 分析长期趋势
            long_trend_score = self._analyze_long_trend(stock_subset)
            
            # 2. 分析波段特征
            wave_score = self._analyze_wave_characteristics(stock_subset)
            
            # 3. 分析高低点抬升
            elevation_score = self._analyze_elevation(stock_subset)
            
            # 综合评分 - 调整权重让波段式上升更容易被识别
            total_score = (long_trend_score * 0.5 + 
                          wave_score * 0.25 + 
                          elevation_score * 0.25)
            
            # 判断是否为波段式上升 - 降低阈值
            is_wave_uptrend = total_score >= 0.5
            
            results.append({
                '代码': stock_code,
                '名称': stock_subset['名称'].iloc[0],
                '长期趋势评分': round(long_trend_score, 3),
                '波段特征评分': round(wave_score, 3),
                '抬升特征评分': round(elevation_score, 3),
                '综合评分': round(total_score, 3),
                '是否波段式上升': is_wave_uptrend,
                '最新价': stock_subset['最新价'].iloc[-1],
                '价格变化': round((stock_subset['最新价'].iloc[-1] / stock_subset['最新价'].iloc[0] - 1) * 100, 2)
            })
        
        return pd.DataFrame(results).sort_values('综合评分', ascending=False)
    
    def _analyze_long_trend(self, stock_data):
        """
        分析长期趋势
        
        Args:
            stock_data: 单只股票数据
        
        Returns:
            长期趋势评分
        """
        long_ma = stock_data['长期均线'].dropna()
        
        if len(long_ma) < 5:
            return 0.0
        
        # 线性回归分析趋势
        x = np.arange(len(long_ma))
        slope, _, r_value, _, _ = stats.linregress(x, long_ma)
        
        # 标准化斜率
        normalized_slope = slope / long_ma.mean() * 100
        
        # 评分 - 降低要求，更容易识别上升趋势
        if normalized_slope > 0.1:  # 降低阈值
            trend_score = min(1.0, normalized_slope / 0.8)  # 降低分母
        elif normalized_slope > 0:
            trend_score = normalized_slope / 0.1 * 0.7  # 提高基础分
        else:
            trend_score = 0.0
        
        # 考虑拟合度
        trend_score *= (r_value ** 2)
        
        return max(0.0, min(1.0, trend_score))
    
    def _analyze_wave_characteristics(self, stock_data):
        """
        分析波段特征
        
        Args:
            stock_data: 单只股票数据
        
        Returns:
            波段特征评分
        """
        prices = stock_data['最新价'].values
        
        if len(prices) < 10:
            return 0.0
        
        # 寻找局部极值
        local_maxima = argrelextrema(prices, np.greater, order=2)[0]
        local_minima = argrelextrema(prices, np.less, order=2)[0]
        
        if len(local_maxima) < 2 or len(local_minima) < 2:
            return 0.0
        
        wave_score = 0.0
        
        # 1. 波段数量评分
        total_extrema = len(local_maxima) + len(local_minima)
        ideal_extrema = len(prices) // 6  # 理想的极值点数量
        
        if ideal_extrema > 0:
            extrema_score = 1.0 - abs(total_extrema - ideal_extrema) / ideal_extrema
            wave_score += max(0.0, extrema_score) * 0.4
        
        # 2. 波动规律性
        if len(local_maxima) >= 2:
            peak_intervals = np.diff(local_maxima)
            if len(peak_intervals) > 1:
                cv = np.std(peak_intervals) / np.mean(peak_intervals)
                regularity_score = max(0.0, 1.0 - cv)
                wave_score += regularity_score * 0.3
        
        # 3. 波动幅度适中
        volatility = np.std(prices) / np.mean(prices)
        if 0.03 <= volatility <= 0.25:
            volatility_score = 1.0 - abs(volatility - 0.1) / 0.15
            wave_score += max(0.0, volatility_score) * 0.3
        
        return max(0.0, min(1.0, wave_score))
    
    def _analyze_elevation(self, stock_data):
        """
        分析高低点抬升特征
        
        Args:
            stock_data: 单只股票数据
        
        Returns:
            抬升特征评分
        """
        prices = stock_data['最新价'].values
        
        if len(prices) < 10:
            return 0.0
        
        # 寻找局部极值
        local_maxima_idx = argrelextrema(prices, np.greater, order=2)[0]
        local_minima_idx = argrelextrema(prices, np.less, order=2)[0]
        
        elevation_score = 0.0
        
        # 分析低点抬升
        if len(local_minima_idx) >= 3:
            minima_values = prices[local_minima_idx]
            x = np.arange(len(minima_values))
            slope_min, _, r_value_min, _, _ = stats.linregress(x, minima_values)
            
            if slope_min > 0:
                min_score = min(1.0, slope_min / np.mean(minima_values) * 30)
                min_score *= (r_value_min ** 2)
                elevation_score += min_score * 0.5
        
        # 分析高点抬升
        if len(local_maxima_idx) >= 3:
            maxima_values = prices[local_maxima_idx]
            x = np.arange(len(maxima_values))
            slope_max, _, r_value_max, _, _ = stats.linregress(x, maxima_values)
            
            if slope_max > 0:
                max_score = min(1.0, slope_max / np.mean(maxima_values) * 30)
                max_score *= (r_value_max ** 2)
                elevation_score += max_score * 0.5
        
        return max(0.0, min(1.0, elevation_score))
    
    def visualize_results(self, stock_data, detection_results):
        """
        可视化检测结果
        
        Args:
            stock_data: 股票数据
            detection_results: 检测结果
        """
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # 1. 显示所有股票的价格走势
        ax1 = axes[0, 0]
        for stock_code in stock_data['代码'].unique():
            stock_subset = stock_data[stock_data['代码'] == stock_code]
            stock_subset = stock_subset.sort_values('交易日期')
            
            # 判断是否为波段式上升
            is_wave = detection_results[
                detection_results['代码'] == stock_code
            ]['是否波段式上升'].iloc[0] if len(detection_results) > 0 else False
            
            color = 'red' if is_wave else 'blue'
            linestyle = '-' if is_wave else '--'
            
            ax1.plot(stock_subset['交易日期'], stock_subset['最新价'], 
                    color=color, linestyle=linestyle, 
                    label=f"{stock_subset['名称'].iloc[0]} ({'波段式' if is_wave else '其他'})")
        
        ax1.set_title('股票价格走势对比')
        ax1.set_xlabel('日期')
        ax1.set_ylabel('价格')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. 评分分布
        ax2 = axes[0, 1]
        score_columns = ['长期趋势评分', '波段特征评分', '抬升特征评分']
        x = np.arange(len(detection_results))
        width = 0.25
        
        for i, col in enumerate(score_columns):
            ax2.bar(x + i*width, detection_results[col], width, 
                   label=col, alpha=0.8)
        
        ax2.set_title('各项评分对比')
        ax2.set_xlabel('股票')
        ax2.set_ylabel('评分')
        ax2.set_xticks(x + width)
        ax2.set_xticklabels(detection_results['代码'])
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. 综合评分排名
        ax3 = axes[0, 2]
        colors = ['red' if x else 'blue' for x in detection_results['是否波段式上升']]
        bars = ax3.bar(detection_results['代码'], detection_results['综合评分'], 
                      color=colors, alpha=0.7)
        ax3.axhline(y=0.6, color='green', linestyle='--', label='阈值线')
        ax3.set_title('综合评分排名')
        ax3.set_xlabel('股票代码')
        ax3.set_ylabel('综合评分')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # 添加数值标签
        for bar, score in zip(bars, detection_results['综合评分']):
            ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{score:.2f}', ha='center', va='bottom')
        
        # 4. 详细展示第一只股票（波段式上升示例）
        ax4 = axes[1, 0]
        first_stock = stock_data[stock_data['代码'] == stock_data['代码'].unique()[0]]
        first_stock = first_stock.sort_values('交易日期')
        
        ax4.plot(first_stock['交易日期'], first_stock['最新价'], 'b-', label='价格', linewidth=2)
        ax4.plot(first_stock['交易日期'], first_stock['短期均线'], 'r--', label='短期均线')
        ax4.plot(first_stock['交易日期'], first_stock['长期均线'], 'g--', label='长期均线')
        
        # 标记局部极值点
        prices = first_stock['最新价'].values
        dates = first_stock['交易日期'].values
        
        local_maxima = argrelextrema(prices, np.greater, order=2)[0]
        local_minima = argrelextrema(prices, np.less, order=2)[0]
        
        if len(local_maxima) > 0:
            ax4.scatter(dates[local_maxima], prices[local_maxima], 
                       color='red', s=50, marker='^', label='波峰')
        
        if len(local_minima) > 0:
            ax4.scatter(dates[local_minima], prices[local_minima], 
                       color='green', s=50, marker='v', label='波谷')
        
        ax4.set_title(f'{first_stock["名称"].iloc[0]} - 波段式上升示例')
        ax4.set_xlabel('日期')
        ax4.set_ylabel('价格')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # 5. 形态分布饼图
        ax5 = axes[1, 1]
        wave_count = len(detection_results[detection_results['是否波段式上升']])
        other_count = len(detection_results) - wave_count
        
        labels = ['波段式上升', '其他形态']
        sizes = [wave_count, other_count]
        colors = ['lightcoral', 'lightblue']
        
        ax5.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
        ax5.set_title('股票形态分布')
        
        # 6. 价格变化对比
        ax6 = axes[1, 2]
        colors = ['red' if x else 'blue' for x in detection_results['是否波段式上升']]
        bars = ax6.bar(detection_results['代码'], detection_results['价格变化'], 
                      color=colors, alpha=0.7)
        ax6.axhline(y=0, color='black', linestyle='-', alpha=0.5)
        ax6.set_title('价格变化幅度 (%)')
        ax6.set_xlabel('股票代码')
        ax6.set_ylabel('价格变化 (%)')
        ax6.grid(True, alpha=0.3)
        
        # 添加数值标签
        for bar, change in zip(bars, detection_results['价格变化']):
            ax6.text(bar.get_x() + bar.get_width()/2, 
                    bar.get_height() + (1 if change >= 0 else -2),
                    f'{change:.1f}%', ha='center', 
                    va='bottom' if change >= 0 else 'top')
        
        plt.tight_layout()
        plt.show()
    
    def print_detailed_results(self, detection_results):
        """
        打印详细检测结果
        
        Args:
            detection_results: 检测结果
        """
        print("\n=== 波段式上升形态检测结果 ===")
        print(f"总股票数: {len(detection_results)}")
        
        wave_stocks = detection_results[detection_results['是否波段式上升']]
        print(f"波段式上升股票: {len(wave_stocks)}")
        print(f"检出率: {len(wave_stocks)/len(detection_results)*100:.1f}%")
        
        print("\n详细结果:")
        print("=" * 80)
        print(f"{'代码':<8} {'名称':<10} {'综合评分':<8} {'趋势':<6} {'波段':<6} {'抬升':<6} {'形态':<8} {'价格变化':<8}")
        print("=" * 80)
        
        for _, row in detection_results.iterrows():
            pattern = "波段式" if row['是否波段式上升'] else "其他"
            print(f"{row['代码']:<8} {row['名称']:<10} {row['综合评分']:<8.3f} "
                  f"{row['长期趋势评分']:<6.3f} {row['波段特征评分']:<6.3f} {row['抬升特征评分']:<6.3f} "
                  f"{pattern:<8} {row['价格变化']:>6.1f}%")
        
        print("=" * 80)
        
        if len(wave_stocks) > 0:
            print("\n波段式上升股票特征分析:")
            print(f"- 平均综合评分: {wave_stocks['综合评分'].mean():.3f}")
            print(f"- 平均长期趋势评分: {wave_stocks['长期趋势评分'].mean():.3f}")
            print(f"- 平均波段特征评分: {wave_stocks['波段特征评分'].mean():.3f}")
            print(f"- 平均抬升特征评分: {wave_stocks['抬升特征评分'].mean():.3f}")
            print(f"- 平均价格变化: {wave_stocks['价格变化'].mean():.1f}%")


def main():
    """
    主函数 - 演示简化版波段式上升检测
    """
    print("简化版波段式上升股票检测器")
    print("=" * 50)
    
    # 创建检测器
    detector = SimpleWaveDetector(long_period=20, short_period=5)
    
    # 创建示例数据
    stock_data = detector.create_sample_data(n_stocks=5, n_days=30)
    
    print("\n示例数据概览:")
    print(stock_data.groupby('代码').agg({
        '名称': 'first',
        '最新价': ['first', 'last'],
        '涨跌幅': 'mean'
    }).round(2))
    
    # 计算技术指标
    stock_data_with_indicators = detector.calculate_indicators(stock_data)
    
    # 检测波段式上升形态
    detection_results = detector.detect_wave_pattern(stock_data_with_indicators)
    
    # 打印详细结果
    detector.print_detailed_results(detection_results)
    
    # 可视化结果
    print("\n生成可视化图表...")
    detector.visualize_results(stock_data_with_indicators, detection_results)
    
    print("\n=== 检测说明 ===")
    print("1. 长期趋势评分: 基于长期均线的上升趋势强度")
    print("2. 波段特征评分: 基于价格波动的规律性和适中性")
    print("3. 抬升特征评分: 基于高点和低点的抬升趋势")
    print("4. 综合评分 >= 0.6 判定为波段式上升形态")
    print("\n波段式上升特征:")
    print("- 长期均线向上倾斜")
    print("- 价格呈现规律性波动")
    print("- 低点逐步抬升")
    print("- 高点逐步抬升")
    print("- 整体保持上升趋势")


if __name__ == "__main__":
    main()