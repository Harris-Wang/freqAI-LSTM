# TSFresh在A股K线形态识别中的应用指南

## 概述

本指南提供了使用TSFresh框架进行A股股票K线形态识别的完整解决方案，包括理论分析、代码示例和实际应用指导。

## 文件说明

### 1. 分析报告
- **`tsfresh_analysis_report.md`** - TSFresh技术可行性分析报告
  - 框架功能详解
  - A股数据适配性分析
  - 应用场景和策略建议

### 2. 代码示例
- **`tsfresh_stock_pattern_demo.py`** - 完整的股票形态识别演示
  - 数据加载和预处理
  - 特征提取和分析
  - 聚类分析和可视化
  - 报告生成

- **`tsfresh_quick_start.py`** - 快速入门示例
  - 基础用法演示
  - 简化的数据处理流程
  - 适合初学者理解概念

### 3. 依赖管理
- **`requirements_tsfresh.txt`** - 所需Python包列表

## 快速开始

### 1. 环境准备

```bash
# 安装依赖包
pip install -r requirements_tsfresh.txt

# 或者使用conda（推荐）
conda install -c conda-forge tsfresh pandas scikit-learn matplotlib seaborn
```

### 2. 运行快速入门示例

```bash
python tsfresh_quick_start.py
```

这个示例会：
- 创建模拟股票数据
- 演示TSFresh的基本用法
- 展示特征提取过程
- 进行简单的模式分析

### 3. 运行完整演示

```bash
python tsfresh_stock_pattern_demo.py
```

这个示例会：
- 加载真实的股票数据
- 进行完整的特征提取
- 执行聚类分析
- 生成可视化图表
- 输出详细分析报告

## TSFresh核心概念

### 1. 时间序列特征提取

TSFresh能够从时间序列数据中自动提取大量统计特征，包括：

- **统计特征**: 均值、方差、偏度、峰度等
- **频域特征**: FFT系数、功率谱密度等
- **时域特征**: 自相关、趋势分析等
- **复杂特征**: 近似熵、样本熵、分形维数等

### 2. 数据格式要求

TSFresh需要特定的数据格式：

```python
# 标准格式
df = pd.DataFrame({
    'id': ['stock_A', 'stock_A', 'stock_B', 'stock_B'],  # 时间序列标识
    'time': [0, 1, 0, 1],                                # 时间点
    'value': [10.5, 11.2, 8.3, 8.7]                     # 数值
})
```

### 3. 特征提取参数

```python
from tsfresh.feature_extraction import (
    MinimalFCParameters,      # 最小特征集
    EfficientFCParameters,    # 高效特征集
    ComprehensiveFCParameters # 综合特征集
)
```

## 在股票分析中的应用

### 1. 数据准备

将股票数据转换为时间序列格式：

```python
# 示例：将涨跌幅数据转换为时间序列
for stock_code in stock_data['代码'].unique():
    stock_subset = stock_data[stock_data['代码'] == stock_code]
    for idx, row in stock_subset.iterrows():
        tsfresh_data.append({
            'id': f"{stock_code}_涨跌幅",
            'time': idx,
            'value': row['涨跌幅']
        })
```

### 2. 特征提取

```python
from tsfresh import extract_features

# 提取特征
features = extract_features(
    tsfresh_data,
    column_id='id',
    column_sort='time',
    column_value='value'
)
```

### 3. 模式识别

```python
from sklearn.cluster import KMeans

# 聚类分析
kmeans = KMeans(n_clusters=5)
cluster_labels = kmeans.fit_predict(features)
```

## 实际应用场景

### 1. 涨停板形态识别
- 分析涨停股的价格和成交量模式
- 识别不同类型的涨停形态
- 预测涨停持续性

### 2. 趋势模式分析
- 识别上升、下降、震荡趋势
- 分析趋势强度和持续性
- 发现趋势转换信号

### 3. 异常检测
- 识别异常交易行为
- 发现市场操纵迹象
- 检测数据质量问题

### 4. 相似股票发现
- 基于交易模式聚类股票
- 发现具有相似行为的股票组合
- 构建投资组合

## 性能优化建议

### 1. 数据量控制
- 合理选择时间窗口
- 使用采样减少数据量
- 分批处理大数据集

### 2. 特征选择
- 使用MinimalFCParameters加快速度
- 根据需求自定义特征参数
- 移除无关特征

### 3. 计算优化
- 使用多进程并行计算
- 启用numba加速
- 合理设置内存使用

```python
# 并行计算示例
features = extract_features(
    tsfresh_data,
    column_id='id',
    column_sort='time',
    column_value='value',
    n_jobs=4  # 使用4个进程
)
```

## 常见问题解决

### 1. 安装问题

**问题**: TSFresh安装失败
**解决**: 
```bash
# 使用conda安装（推荐）
conda install -c conda-forge tsfresh

# 或者升级pip后重试
pip install --upgrade pip
pip install tsfresh
```

### 2. 内存问题

**问题**: 内存不足
**解决**: 
- 减少数据量
- 使用MinimalFCParameters
- 分批处理数据

### 3. 计算速度慢

**问题**: 特征提取速度慢
**解决**: 
- 使用并行计算
- 减少特征数量
- 优化数据格式

### 4. 特征解释困难

**问题**: 提取的特征难以理解
**解决**: 
- 查阅TSFresh文档了解特征含义
- 使用特征重要性分析
- 结合领域知识筛选特征

## 进阶应用

### 1. 自定义特征

```python
from tsfresh.feature_extraction.feature_calculators import *

# 定义自定义特征参数
custom_fc_parameters = {
    'mean': None,
    'variance': None,
    'trend': [{'param': [{'chunk_len': 5}]}]
}
```

### 2. 特征选择

```python
from tsfresh import select_features

# 基于目标变量选择特征
selected_features = select_features(
    features, 
    target_variable,
    ml_task='classification'
)
```

### 3. 实时分析

```python
# 滚动窗口分析
window_size = 20
for i in range(window_size, len(stock_data)):
    window_data = stock_data[i-window_size:i]
    # 提取特征并分析
```

## 参考资源

- [TSFresh官方文档](https://tsfresh.readthedocs.io/)
- [TSFresh GitHub仓库](https://github.com/blue-yonder/tsfresh)
- [时间序列特征工程指南](https://tsfresh.readthedocs.io/en/latest/text/feature_extraction_settings.html)
- [机器学习在金融中的应用](https://scikit-learn.org/stable/)

## 注意事项

1. **数据质量**: 确保输入数据的准确性和完整性
2. **过拟合风险**: 避免使用过多特征导致过拟合
3. **计算资源**: 大规模数据处理需要充足的计算资源
4. **结果解释**: 结合金融领域知识解释分析结果
5. **风险控制**: 分析结果仅供参考，不构成投资建议

## 联系与支持

如果在使用过程中遇到问题，可以：
1. 查阅TSFresh官方文档
2. 在GitHub上提交issue
3. 参考相关学术论文和案例研究

---

**免责声明**: 本指南仅用于技术学习和研究目的，不构成任何投资建议。股市有风险，投资需谨慎。