#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TSFresh在A股K线形态识别中的应用示例

本示例展示如何使用TSFresh框架从股票K线数据中提取特征，
并进行形态识别和模式发现。

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# TSFresh相关导入
try:
    from tsfresh import extract_features, select_features
    from tsfresh.utilities.dataframe_functions import impute
    from tsfresh.feature_extraction import ComprehensiveFCParameters
    TSFRESH_AVAILABLE = True
except ImportError:
    print("警告: TSFresh未安装，请运行: pip install tsfresh")
    TSFRESH_AVAILABLE = False

# 机器学习相关导入
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# 可视化导入
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
plt.rcParams['axes.unicode_minus'] = False


class TSFreshStockPatternAnalyzer:
    """
    基于TSFresh的股票K线形态分析器
    
    该类提供了完整的股票数据处理、特征提取、形态识别功能
    """
    
    def __init__(self, data_dir: str = "data/zt_data"):
        """
        初始化分析器
        
        Args:
            data_dir: 股票数据目录路径
        """
        self.data_dir = Path(data_dir)
        self.features = None
        self.tsfresh_data = None
        self.stock_data = None
        
        if not TSFRESH_AVAILABLE:
            raise ImportError("TSFresh未安装，请先安装: pip install tsfresh")
    
    def load_stock_data(self, date_range: list = None, stock_pools: list = None) -> pd.DataFrame:
        """
        加载股票数据
        
        Args:
            date_range: 日期范围列表，如['20250715', '20250721']
            stock_pools: 股池类型列表，如['涨停股池', '强势股池']
        
        Returns:
            合并后的股票数据DataFrame
        """
        all_data = []
        
        # 获取所有可用日期
        available_dates = [d.name for d in self.data_dir.iterdir() if d.is_dir()]
        available_dates.sort()
        
        if date_range:
            available_dates = [d for d in available_dates if date_range[0] <= d <= date_range[1]]
        
        # 默认股池类型
        if stock_pools is None:
            stock_pools = ['涨停股池', '强势股池', '昨日涨停股池']
        
        print(f"正在加载数据，日期范围: {available_dates[0]} 到 {available_dates[-1]}")
        print(f"股池类型: {stock_pools}")
        
        for date_str in available_dates:
            date_dir = self.data_dir / date_str
            
            for pool_type in stock_pools:
                csv_file = date_dir / f"{pool_type}_{date_str}.csv"
                
                if csv_file.exists():
                    try:
                        df = pd.read_csv(csv_file, encoding='utf-8-sig')
                        df['交易日期'] = date_str
                        df['股池类型'] = pool_type
                        all_data.append(df)
                    except Exception as e:
                        print(f"读取文件失败: {csv_file}, 错误: {e}")
        
        if not all_data:
            raise ValueError("未找到任何数据文件")
        
        # 合并所有数据
        self.stock_data = pd.concat(all_data, ignore_index=True)
        
        # 数据清洗
        self.stock_data = self._clean_data(self.stock_data)
        
        print(f"数据加载完成，共 {len(self.stock_data)} 条记录")
        print(f"涵盖 {len(self.stock_data['代码'].unique())} 只股票")
        print(f"时间跨度: {len(available_dates)} 个交易日")
        
        return self.stock_data
    
    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        清洗股票数据
        
        Args:
            df: 原始数据DataFrame
        
        Returns:
            清洗后的DataFrame
        """
        # 移除百分号并转换为数值
        percentage_columns = ['涨跌幅', '换手率']
        for col in percentage_columns:
            if col in df.columns:
                df[col] = df[col].str.replace('%', '').astype(float)
        
        # 处理价格和金额字段
        price_columns = ['最新价']
        for col in price_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # 处理成交额（转换为数值，单位：万元）
        if '成交额' in df.columns:
            df['成交额_万元'] = df['成交额'].apply(self._parse_amount)
        
        # 处理市值（转换为数值，单位：亿元）
        market_cap_columns = ['流通市值', '总市值']
        for col in market_cap_columns:
            if col in df.columns:
                df[f'{col}_亿元'] = df[col].apply(self._parse_market_cap)
        
        # 移除缺失值过多的行
        df = df.dropna(subset=['代码', '名称', '最新价'])
        
        return df
    
    def _parse_amount(self, amount_str: str) -> float:
        """
        解析成交额字符串，转换为万元
        
        Args:
            amount_str: 成交额字符串，如"7589万"、"7.09亿"
        
        Returns:
            成交额数值（万元）
        """
        if pd.isna(amount_str):
            return np.nan
        
        amount_str = str(amount_str).strip()
        
        if '万' in amount_str:
            return float(amount_str.replace('万', ''))
        elif '亿' in amount_str:
            return float(amount_str.replace('亿', '')) * 10000
        else:
            try:
                return float(amount_str)
            except:
                return np.nan
    
    def _parse_market_cap(self, cap_str: str) -> float:
        """
        解析市值字符串，转换为亿元
        
        Args:
            cap_str: 市值字符串，如"14.04亿"
        
        Returns:
            市值数值（亿元）
        """
        if pd.isna(cap_str):
            return np.nan
        
        cap_str = str(cap_str).strip()
        
        if '亿' in cap_str:
            return float(cap_str.replace('亿', ''))
        elif '万' in cap_str:
            return float(cap_str.replace('万', '')) / 10000
        else:
            try:
                return float(cap_str)
            except:
                return np.nan
    
    def prepare_tsfresh_data(self, value_columns: list = None) -> pd.DataFrame:
        """
        将股票数据转换为TSFresh格式
        
        Args:
            value_columns: 要分析的数值列，默认为主要价格和成交量指标
        
        Returns:
            TSFresh格式的DataFrame
        """
        if self.stock_data is None:
            raise ValueError("请先加载股票数据")
        
        if value_columns is None:
            value_columns = [
                '涨跌幅', '最新价', '换手率', 
                '成交额_万元', '流通市值_亿元', '总市值_亿元'
            ]
        
        # 过滤存在的列
        available_columns = [col for col in value_columns if col in self.stock_data.columns]
        
        print(f"准备TSFresh数据，分析指标: {available_columns}")
        
        tsfresh_data = []
        
        # 按股票代码分组
        for stock_code in self.stock_data['代码'].unique():
            stock_subset = self.stock_data[self.stock_data['代码'] == stock_code].copy()
            stock_subset = stock_subset.sort_values('交易日期')
            
            # 为每个指标创建时间序列
            for column in available_columns:
                for idx, (_, row) in enumerate(stock_subset.iterrows()):
                    if pd.notna(row[column]):
                        tsfresh_data.append({
                            'id': f"{stock_code}_{column}",
                            'time': idx,  # 使用序号作为时间
                            'value': row[column],
                            'stock_code': stock_code,
                            'date': row['交易日期'],
                            'metric': column
                        })
        
        self.tsfresh_data = pd.DataFrame(tsfresh_data)
        
        print(f"TSFresh数据准备完成，共 {len(self.tsfresh_data)} 个数据点")
        print(f"涵盖 {len(self.tsfresh_data['stock_code'].unique())} 只股票")
        print(f"分析指标: {len(available_columns)} 个")
        
        return self.tsfresh_data
    
    def extract_features(self, feature_settings: dict = None) -> pd.DataFrame:
        """
        使用TSFresh提取时间序列特征
        
        Args:
            feature_settings: 特征提取设置，默认使用综合参数
        
        Returns:
            提取的特征DataFrame
        """
        if self.tsfresh_data is None:
            raise ValueError("请先准备TSFresh数据")
        
        print("开始提取时间序列特征...")
        
        # 使用默认的综合特征参数
        if feature_settings is None:
            feature_settings = ComprehensiveFCParameters()
        
        # 提取特征
        self.features = extract_features(
            self.tsfresh_data,
            column_id='id',
            column_sort='time',
            column_value='value',
            default_fc_parameters=feature_settings,
            n_jobs=1  # 单线程避免潜在问题
        )
        
        # 处理缺失值和无穷值
        impute(self.features)
        
        print(f"特征提取完成，共提取 {self.features.shape[1]} 个特征")
        print(f"特征矩阵形状: {self.features.shape}")
        
        return self.features
    
    def analyze_feature_importance(self, target_column: str = None) -> pd.DataFrame:
        """
        分析特征重要性
        
        Args:
            target_column: 目标变量列名，用于监督学习的特征选择
        
        Returns:
            特征重要性DataFrame
        """
        if self.features is None:
            raise ValueError("请先提取特征")
        
        # 计算特征的基本统计信息
        feature_stats = pd.DataFrame({
            'feature_name': self.features.columns,
            'mean': self.features.mean(),
            'std': self.features.std(),
            'min': self.features.min(),
            'max': self.features.max(),
            'non_zero_ratio': (self.features != 0).mean()
        })
        
        # 移除方差为0的特征
        feature_stats = feature_stats[feature_stats['std'] > 0]
        
        print(f"有效特征数量: {len(feature_stats)}")
        
        return feature_stats.sort_values('std', ascending=False)
    
    def cluster_patterns(self, n_clusters: int = 8, random_state: int = 42) -> dict:
        """
        使用无监督聚类识别股票模式
        
        Args:
            n_clusters: 聚类数量
            random_state: 随机种子
        
        Returns:
            聚类结果字典
        """
        if self.features is None:
            raise ValueError("请先提取特征")
        
        print(f"开始聚类分析，聚类数量: {n_clusters}")
        
        # 标准化特征
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(self.features)
        
        # K-means聚类
        kmeans = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
        cluster_labels = kmeans.fit_predict(features_scaled)
        
        # 解析股票代码和指标
        stock_info = []
        for idx in self.features.index:
            parts = idx.split('_')
            if len(parts) >= 2:
                stock_code = parts[0]
                metric = '_'.join(parts[1:])
                stock_info.append({'stock_code': stock_code, 'metric': metric})
            else:
                stock_info.append({'stock_code': 'unknown', 'metric': 'unknown'})
        
        # 创建结果DataFrame
        cluster_results = pd.DataFrame({
            'id': self.features.index,
            'stock_code': [info['stock_code'] for info in stock_info],
            'metric': [info['metric'] for info in stock_info],
            'cluster': cluster_labels
        })
        
        # 统计每个聚类的特征
        cluster_summary = cluster_results.groupby('cluster').agg({
            'stock_code': 'count',
            'metric': lambda x: list(x.unique())
        }).rename(columns={'stock_code': 'count'})
        
        print("聚类结果:")
        for cluster_id, row in cluster_summary.iterrows():
            print(f"聚类 {cluster_id}: {row['count']} 个样本")
        
        return {
            'cluster_labels': cluster_labels,
            'cluster_results': cluster_results,
            'cluster_summary': cluster_summary,
            'kmeans_model': kmeans,
            'scaler': scaler
        }
    
    def visualize_clusters(self, cluster_results: dict, save_path: str = None):
        """
        可视化聚类结果
        
        Args:
            cluster_results: 聚类结果字典
            save_path: 保存路径
        """
        plt.figure(figsize=(15, 10))
        
        # 1. 聚类分布饼图
        plt.subplot(2, 3, 1)
        cluster_counts = cluster_results['cluster_results']['cluster'].value_counts().sort_index()
        plt.pie(cluster_counts.values, labels=[f'聚类{i}' for i in cluster_counts.index], autopct='%1.1f%%')
        plt.title('聚类分布')
        
        # 2. 每个聚类的股票数量
        plt.subplot(2, 3, 2)
        stock_cluster_counts = cluster_results['cluster_results'].groupby('cluster')['stock_code'].nunique()
        plt.bar(stock_cluster_counts.index, stock_cluster_counts.values)
        plt.xlabel('聚类ID')
        plt.ylabel('股票数量')
        plt.title('各聚类包含的股票数量')
        
        # 3. 指标分布热力图
        plt.subplot(2, 3, 3)
        metric_cluster = pd.crosstab(cluster_results['cluster_results']['metric'], 
                                   cluster_results['cluster_results']['cluster'])
        sns.heatmap(metric_cluster, annot=True, fmt='d', cmap='Blues')
        plt.title('指标-聚类分布热力图')
        plt.xticks(rotation=45)
        plt.yticks(rotation=0)
        
        # 4. 聚类中心可视化（选择前几个主要特征）
        plt.subplot(2, 3, 4)
        if self.features is not None:
            # 选择方差最大的前10个特征进行可视化
            feature_vars = self.features.var().sort_values(ascending=False)
            top_features = feature_vars.head(10).index
            
            cluster_centers = []
            for i in range(len(cluster_results['kmeans_model'].cluster_centers_)):
                center = cluster_results['kmeans_model'].cluster_centers_[i]
                # 反标准化
                center_original = cluster_results['scaler'].inverse_transform([center])[0]
                cluster_centers.append(center_original)
            
            # 只显示前几个特征的聚类中心
            centers_df = pd.DataFrame(cluster_centers, columns=self.features.columns)
            centers_subset = centers_df[top_features[:5]]  # 只显示前5个特征
            
            sns.heatmap(centers_subset.T, annot=True, fmt='.2f', cmap='RdYlBu_r')
            plt.title('聚类中心特征值')
            plt.xlabel('聚类ID')
            plt.ylabel('特征')
        
        # 5. 股票代码在各聚类中的分布
        plt.subplot(2, 3, 5)
        top_stocks = cluster_results['cluster_results']['stock_code'].value_counts().head(10)
        plt.barh(range(len(top_stocks)), top_stocks.values)
        plt.yticks(range(len(top_stocks)), top_stocks.index)
        plt.xlabel('出现次数')
        plt.title('出现频次最高的股票')
        
        # 6. 聚类质量评估
        plt.subplot(2, 3, 6)
        if hasattr(cluster_results['kmeans_model'], 'inertia_'):
            inertias = []
            K_range = range(2, min(11, len(cluster_results['cluster_results']) // 2))
            
            for k in K_range:
                kmeans_temp = KMeans(n_clusters=k, random_state=42, n_init=10)
                features_scaled = cluster_results['scaler'].transform(self.features)
                kmeans_temp.fit(features_scaled)
                inertias.append(kmeans_temp.inertia_)
            
            plt.plot(K_range, inertias, 'bo-')
            plt.xlabel('聚类数量 (K)')
            plt.ylabel('簇内平方和 (Inertia)')
            plt.title('肘部法则 - 最优聚类数')
            plt.grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"图表已保存到: {save_path}")
        
        plt.show()
    
    def generate_pattern_report(self, cluster_results: dict) -> str:
        """
        生成形态识别报告
        
        Args:
            cluster_results: 聚类结果字典
        
        Returns:
            报告文本
        """
        report = []
        report.append("=" * 60)
        report.append("TSFresh股票形态识别分析报告")
        report.append("=" * 60)
        report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # 数据概览
        report.append("## 数据概览")
        if self.stock_data is not None:
            report.append(f"- 分析股票数量: {len(self.stock_data['代码'].unique())}")
            report.append(f"- 数据记录总数: {len(self.stock_data)}")
            report.append(f"- 时间跨度: {self.stock_data['交易日期'].min()} 至 {self.stock_data['交易日期'].max()}")
        
        if self.features is not None:
            report.append(f"- 提取特征数量: {self.features.shape[1]}")
            report.append(f"- 特征样本数量: {self.features.shape[0]}")
        
        report.append("")
        
        # 聚类分析结果
        report.append("## 聚类分析结果")
        cluster_summary = cluster_results['cluster_summary']
        
        for cluster_id, row in cluster_summary.iterrows():
            report.append(f"### 聚类 {cluster_id}")
            report.append(f"- 样本数量: {row['count']}")
            report.append(f"- 涉及指标: {', '.join(row['metric'])}")
            
            # 获取该聚类中的股票
            cluster_stocks = cluster_results['cluster_results'][
                cluster_results['cluster_results']['cluster'] == cluster_id
            ]['stock_code'].unique()
            
            if len(cluster_stocks) <= 10:
                report.append(f"- 包含股票: {', '.join(cluster_stocks)}")
            else:
                report.append(f"- 包含股票: {', '.join(cluster_stocks[:10])} 等{len(cluster_stocks)}只")
            
            report.append("")
        
        # 特征重要性分析
        if self.features is not None:
            report.append("## 特征重要性分析")
            feature_stats = self.analyze_feature_importance()
            top_features = feature_stats.head(10)
            
            report.append("### 方差最大的前10个特征:")
            for idx, (_, row) in enumerate(top_features.iterrows(), 1):
                report.append(f"{idx}. {row['feature_name']}: 标准差={row['std']:.4f}")
            
            report.append("")
        
        # 投资建议
        report.append("## 投资建议")
        report.append("基于聚类分析结果，建议关注以下几点:")
        report.append("1. 不同聚类代表不同的市场行为模式")
        report.append("2. 可以根据聚类结果制定差异化的投资策略")
        report.append("3. 关注聚类中心特征值异常的股票")
        report.append("4. 定期重新分析，跟踪模式变化")
        report.append("")
        
        # 风险提示
        report.append("## 风险提示")
        report.append("1. 本分析基于历史数据，不构成投资建议")
        report.append("2. 市场环境变化可能导致模式失效")
        report.append("3. 建议结合其他分析方法综合判断")
        report.append("4. 投资有风险，入市需谨慎")
        
        return "\n".join(report)


def main():
    """
    主函数 - 演示TSFresh在股票分析中的应用
    """
    print("TSFresh股票K线形态识别演示")
    print("=" * 50)
    
    try:
        # 创建分析器实例
        analyzer = TSFreshStockPatternAnalyzer()
        
        # 加载数据（使用最近几天的数据）
        stock_data = analyzer.load_stock_data(
            date_range=['20250715', '20250721'],
            stock_pools=['涨停股池', '强势股池']
        )
        
        print("\n数据样本:")
        print(stock_data[['代码', '名称', '涨跌幅', '最新价', '交易日期', '股池类型']].head(10))
        
        # 准备TSFresh数据
        tsfresh_data = analyzer.prepare_tsfresh_data()
        
        print("\nTSFresh数据样本:")
        print(tsfresh_data.head(10))
        
        # 提取特征
        features = analyzer.extract_features()
        
        print("\n特征样本:")
        print(features.head())
        
        # 分析特征重要性
        feature_importance = analyzer.analyze_feature_importance()
        
        print("\n重要特征 (前10个):")
        print(feature_importance.head(10)[['feature_name', 'std', 'non_zero_ratio']])
        
        # 聚类分析
        cluster_results = analyzer.cluster_patterns(n_clusters=6)
        
        print("\n聚类结果:")
        print(cluster_results['cluster_summary'])
        
        # 可视化结果
        print("\n生成可视化图表...")
        analyzer.visualize_clusters(cluster_results, save_path="tsfresh_cluster_analysis.png")
        
        # 生成报告
        report = analyzer.generate_pattern_report(cluster_results)
        
        # 保存报告
        with open("tsfresh_pattern_report.txt", "w", encoding="utf-8") as f:
            f.write(report)
        
        print("\n分析完成！")
        print("- 聚类分析图表已保存为: tsfresh_cluster_analysis.png")
        print("- 详细报告已保存为: tsfresh_pattern_report.txt")
        
        # 显示报告摘要
        print("\n=== 报告摘要 ===")
        print(report[:1000] + "..." if len(report) > 1000 else report)
        
    except Exception as e:
        print(f"分析过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()