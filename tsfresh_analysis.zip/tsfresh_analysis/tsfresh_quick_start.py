#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TSFresh快速入门示例

这是一个简化的示例，展示如何快速开始使用TSFresh分析股票数据

作者: AI Assistant
日期: 2025-01-21
"""

import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# 检查TSFresh是否可用
try:
    from tsfresh import extract_features
    from tsfresh.utilities.dataframe_functions import impute
    from tsfresh.feature_extraction import MinimalFCParameters
    print("✓ TSFresh已安装并可用")
except ImportError:
    print("❌ TSFresh未安装")
    print("请运行以下命令安装:")
    print("pip install tsfresh")
    exit(1)


def create_sample_stock_data():
    """
    创建示例股票数据
    
    Returns:
        示例股票数据DataFrame
    """
    print("创建示例股票数据...")
    
    # 模拟3只股票，每只5天的数据
    stocks = ['000001', '000002', '000003']
    dates = ['20250117', '20250118', '20250119', '20250120', '20250121']
    
    data = []
    
    for stock in stocks:
        base_price = np.random.uniform(10, 50)  # 基础价格
        
        for i, date in enumerate(dates):
            # 模拟价格波动
            price_change = np.random.uniform(-0.1, 0.1)  # ±10%波动
            current_price = base_price * (1 + price_change)
            
            data.append({
                '代码': stock,
                '名称': f'股票{stock}',
                '交易日期': date,
                '最新价': round(current_price, 2),
                '涨跌幅': round(price_change * 100, 2),
                '成交额': np.random.uniform(1000, 10000),  # 万元
                '换手率': round(np.random.uniform(1, 15), 2),
                '流通市值': round(np.random.uniform(50, 500), 2)  # 亿元
            })
            
            base_price = current_price  # 更新基础价格
    
    df = pd.DataFrame(data)
    print(f"创建了 {len(df)} 条示例数据")
    return df


def prepare_tsfresh_format(stock_data):
    """
    将股票数据转换为TSFresh格式
    
    Args:
        stock_data: 股票数据DataFrame
    
    Returns:
        TSFresh格式的DataFrame
    """
    print("转换数据格式为TSFresh格式...")
    
    tsfresh_data = []
    
    # 要分析的指标
    metrics = ['最新价', '涨跌幅', '成交额', '换手率', '流通市值']
    
    for stock_code in stock_data['代码'].unique():
        stock_subset = stock_data[stock_data['代码'] == stock_code].copy()
        stock_subset = stock_subset.sort_values('交易日期')
        
        for metric in metrics:
            for time_idx, (_, row) in enumerate(stock_subset.iterrows()):
                tsfresh_data.append({
                    'id': f"{stock_code}_{metric}",  # 时间序列ID
                    'time': time_idx,                # 时间点
                    'value': row[metric]             # 数值
                })
    
    df = pd.DataFrame(tsfresh_data)
    print(f"转换完成，共 {len(df)} 个数据点")
    print(f"包含 {len(df['id'].unique())} 个时间序列")
    
    return df


def extract_tsfresh_features(tsfresh_data):
    """
    使用TSFresh提取特征
    
    Args:
        tsfresh_data: TSFresh格式的数据
    
    Returns:
        提取的特征DataFrame
    """
    print("使用TSFresh提取特征...")
    
    # 使用最小特征集以加快速度
    features = extract_features(
        tsfresh_data,
        column_id='id',
        column_sort='time', 
        column_value='value',
        default_fc_parameters=MinimalFCParameters(),
        disable_progressbar=False
    )
    
    # 处理缺失值
    impute(features)
    
    print(f"特征提取完成！")
    print(f"特征矩阵形状: {features.shape}")
    print(f"提取了 {features.shape[1]} 个特征")
    
    return features


def analyze_features(features):
    """
    分析提取的特征
    
    Args:
        features: 特征DataFrame
    """
    print("\n=== 特征分析 ===")
    
    # 显示特征名称
    print(f"\n特征列表 (共{len(features.columns)}个):")
    for i, col in enumerate(features.columns, 1):
        print(f"{i:2d}. {col}")
    
    # 显示特征统计信息
    print("\n特征统计信息:")
    stats = features.describe()
    print(stats)
    
    # 显示样本数据
    print("\n特征样本数据:")
    print(features.head())
    
    # 分析特征方差
    print("\n特征方差排序 (前10个):")
    feature_vars = features.var().sort_values(ascending=False)
    for i, (feature, variance) in enumerate(feature_vars.head(10).items(), 1):
        print(f"{i:2d}. {feature}: {variance:.6f}")


def demonstrate_pattern_analysis(features):
    """
    演示基于特征的模式分析
    
    Args:
        features: 特征DataFrame
    """
    print("\n=== 模式分析演示 ===")
    
    # 解析时间序列ID
    series_info = []
    for series_id in features.index:
        parts = series_id.split('_')
        if len(parts) >= 2:
            stock_code = parts[0]
            metric = '_'.join(parts[1:])
            series_info.append({'stock_code': stock_code, 'metric': metric})
    
    series_df = pd.DataFrame(series_info, index=features.index)
    
    # 按股票分组分析
    print("\n按股票分组的特征分析:")
    for stock_code in series_df['stock_code'].unique():
        stock_features = features[series_df['stock_code'] == stock_code]
        
        if len(stock_features) > 0:
            # 计算该股票所有特征的平均值
            avg_features = stock_features.mean(axis=0)
            top_features = avg_features.abs().sort_values(ascending=False).head(3)
            
            print(f"\n股票 {stock_code} 的主要特征:")
            for feature, value in top_features.items():
                print(f"  - {feature}: {value:.4f}")
    
    # 按指标分组分析
    print("\n按指标分组的特征分析:")
    for metric in series_df['metric'].unique():
        metric_features = features[series_df['metric'] == metric]
        
        if len(metric_features) > 0:
            # 计算该指标所有特征的平均值
            avg_features = metric_features.mean(axis=0)
            top_features = avg_features.abs().sort_values(ascending=False).head(2)
            
            print(f"\n指标 {metric} 的主要特征:")
            for feature, value in top_features.items():
                print(f"  - {feature}: {value:.4f}")


def main():
    """
    主函数 - TSFresh快速入门演示
    """
    print("TSFresh股票数据分析快速入门")
    print("=" * 50)
    
    try:
        # 步骤1: 创建示例数据
        stock_data = create_sample_stock_data()
        print("\n原始股票数据样本:")
        print(stock_data.head(10))
        
        # 步骤2: 转换为TSFresh格式
        tsfresh_data = prepare_tsfresh_format(stock_data)
        print("\nTSFresh格式数据样本:")
        print(tsfresh_data.head(10))
        
        # 步骤3: 提取特征
        features = extract_tsfresh_features(tsfresh_data)
        
        # 步骤4: 分析特征
        analyze_features(features)
        
        # 步骤5: 演示模式分析
        demonstrate_pattern_analysis(features)
        
        print("\n=== 总结 ===")
        print("✓ 成功创建示例股票数据")
        print("✓ 成功转换为TSFresh格式")
        print("✓ 成功提取时间序列特征")
        print("✓ 成功进行特征分析")
        print("\n这个示例展示了TSFresh的基本用法:")
        print("1. 数据准备: 将股票数据转换为时间序列格式")
        print("2. 特征提取: 自动提取时间序列特征")
        print("3. 特征分析: 分析特征的统计特性")
        print("4. 模式识别: 基于特征进行模式分析")
        
        print("\n下一步可以:")
        print("- 使用真实的股票数据")
        print("- 尝试更多的特征参数")
        print("- 结合机器学习进行分类或聚类")
        print("- 进行时间序列预测")
        
    except Exception as e:
        print(f"\n❌ 运行过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        
        print("\n可能的解决方案:")
        print("1. 确保已安装TSFresh: pip install tsfresh")
        print("2. 确保已安装相关依赖: pip install pandas numpy scikit-learn")
        print("3. 检查Python版本是否兼容")


if __name__ == "__main__":
    main()