"""
邢不行™️选股框架
Python股票量化投资课程

版权所有 ©️ 邢不行
微信: xbx8662

未经授权，不得复制、修改、或使用本代码的全部或部分内容。仅限个人学习用途，禁止商业用途。

Author: 邢不行
"""
import os
import pandas as pd
from pandas.core.interchange.from_dataframe import protocol_df_chunk_to_pandas
import numpy as np
import config as cfg
from core.model.strategy_config import StrategyConfig




def calc_select_factor(df, strategy: StrategyConfig) -> pd.DataFrame:
    """
    计算复合选股因子
    :param df: 整理好的数据，包含因子信息，并做过周期转换
    :param strategy: 策略配置
    :return: 返回过滤后的数据

    ### df 列说明
    包含基础列：  ['交易日期', '股票代码', '股票名称', '周频起始日', '月频起始日', '上市至今交易天数', '复权因子', '开盘价', '最高价',
                '最低价', '收盘价', '成交额', '是否交易', '流通市值', '总市值', '下日_开盘涨停', '下日_是否ST', '下日_是否交易',
                '下日_是否退市']
    以及config中配置好的，因子计算的结果列。

    ### strategy 数据说明
    - strategy.name: 策略名称
    - strategy.hold_period: 持仓周期
    - strategy.select_num: 选股数量
    - strategy.factor_name: 复合因子名称
    - strategy.factor_list: 选股因子列表
    - strategy.filter_list: 过滤因子列表
    - strategy.factor_columns: 选股+过滤因子的列名
    """

    # 读取因子信息
    zdf,gdhs,ndsy = strategy.factor_list

    # df = df[~df['股票代码'].str.contains('sz30')]
    df = df[~df['股票代码'].str.contains('sh68')]
    # print(df)

    df[f'股东户数排名'] = df.groupby('交易日期')[gdhs.col_name].rank(ascending=True, method='min',pct=True)
    df[f'户均市值排名'] = df.groupby('交易日期')[zdf.col_name].rank(ascending=True, method='min', pct=True)

    # df[f'户数分位数排名'] = df.groupby('交易日期')[profit_grow.col_name].rank(ascending=False, method='min', pct=True)
    df = df[df[f'股东户数排名']>0.1]
    # df = df[df[f'户均市值排名'] < 0.9]

    # 计算复合因子
    df['复合因子'] = df[f'股东户数排名'] + df[f'户均市值排名']



    return df

#