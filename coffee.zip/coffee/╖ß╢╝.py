"""
邢不行™️选股框架
Python股票量化投资课程

版权所有 ©️ 邢不行
微信: xbx8662

未经授权，不得复制、修改、或使用本代码的全部或部分内容。仅限个人学习用途，禁止商业用途。

Author: 邢不行
"""
import re
import pandas as pd
from pathlib import Path
from core.model.strategy_config import StrategyConfig
import config as cfg
import numpy as np

"""
使用范例：
    {'name': '主力资金杠杆效率_定风波再择时', 'hold_period': 'W', 'offset_list': [0, 1, 2, 3, 4], 'select_num': 10, 'cap_weight': 1,
     'rebalance_time': '0955-0955',
     'factor_list': [('主力资金杠杆效率', False, 20, 1),
                     ('市值', True, None, 1),
                     ('开盘至今涨幅', False, '0945', ('全市场择时', 0.4)), ],
     'filter_list': []},

开盘涨跌幅参数解析     
    参数1：计算下跌比例的范围
        可填三种类型：全市场择时，前N择时，前N%择时。
        按照规则写即可实现动态调整范围，例如：前100择时，前10%择时
    参数2：下跌比例
"""


def calc_select_factor(df, strategy: StrategyConfig) -> pd.DataFrame:
    """
    计算复合选股因子
    :param df: 整理好的数据，包含因子信息，并做过周期转换
    :param strategy: 策略配置
    :return: 返回过滤后的数据

    ### df 列说明
    包含基础列：  ['交易日期', '股票代码', '股票名称', '周频起始日', '月频起始日', '上市至今交易天数', '复权因子', '开盘价', '最高价',
                '最低价', '收盘价', '成交额', '是否交易', '流通市值', '总市值', '下日_开盘涨停', '下日_是否ST', '下日_是否交易',
                '下日_是否退市']
    以及config中配置好的，因子计算的结果列。

    ### strategy 数据说明
    - strategy.name: 策略名称
    - strategy.hold_period: 持仓周期
    - strategy.select_num: 选股数量
    - strategy.factor_name: 复合因子名称
    - strategy.factor_list: 选股因子列表
    - strategy.filter_list: 过滤因子列表
    - strategy.factor_columns: 选股+过滤因子的列名
    """
    # ret_short,ret_long,industy,mcap,decline =strategy.factor_list
    industy,zd,sp,mcap,ndsy = strategy.factor_list

    # df = df[~df['股票代码'].str.contains('sz30')]

    df = df[~df['股票代码'].str.contains('sh68')]



    df['exprice排名'] = df.groupby(['交易日期'])[zd.col_name].rank(ascending=True, method='min',pct=True)

    df['上方筹码排名'] = df.groupby(['交易日期'])[mcap.col_name].rank(ascending=True, method='min',pct=True)

    df['std排名'] = df.groupby(['交易日期'])[sp.col_name].rank(ascending=True, method='min', pct=True)


    #


    df = df[df['std排名'] < 0.3]





    # df1.to_csv('ztest1.csv')

    df['复合因子'] =   df['上方筹码排名'] +  df['exprice排名']

    return df
