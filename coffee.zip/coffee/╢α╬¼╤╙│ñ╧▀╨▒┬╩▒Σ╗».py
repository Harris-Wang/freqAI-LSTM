"""
邢不行｜策略分享会
选股策略框架𝓟𝓻𝓸

版权所有 ©️ 邢不行
微信: xbx1717

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import pandas as pd
import numpy as np

from core.data_center import calculate_extended_line_all


fin_cols = []

def add_factor(df: pd.DataFrame, param=None, **kwargs) -> pd.DataFrame:
    """
    因子计算主函数，支持根据多个关键点构建趋势线并生成信号

    :param df: 输入的行情数据
    :param param: 参数字典，包含 n（跌停窗口） 和 k（趋势线窗口）
    :param kwargs: 其他参数，如 col_name
    :return: 包含因子信号和趋势线的 DataFrame
    """

    # ======================== 参数处理 ===========================
    col_name = kwargs['col_name']


    # ======================== 计算基础指标 =======================
    df['是否跌停'] = (df['收盘价'] == df['跌停价']).astype(int)
    df['换手率'] = df['成交额'] / df['流通市值']
    # 计算基准价格(用于百分比计算)
    df['base_price'] = df['收盘价']

    # 计算上影线长度和百分比
    df['lower_shadow'] = np.minimum(df['收盘价'], df['开盘价']) - df['最低价']
    df['lower_shadow_pct'] = df['lower_shadow'] / df['base_price'] * 100

    # 年内最低换手率
    df['年内最低换手率'] = df.groupby(df['交易日期'].dt.year)['换手率'].transform(
        lambda x: x.expanding().min()
    )

    # 标记关键点：跌停日 or 换手率年内最低
    df['is_support1']= (df['是否跌停'] == 1) | (df['换手率'] == df['年内最低换手率'])| (2 < df['lower_shadow_pct'])

    result = calculate_extended_line_all(df, condition_series=df['is_support1'])

    df[col_name] = result['slope_change']




    return df[[col_name]]  # 返回包含新增列的结果
