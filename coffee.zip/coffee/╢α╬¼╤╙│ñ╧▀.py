"""
邢不行｜策略分享会
选股策略框架𝓟𝓻𝓸

版权所有 ©️ 邢不行
微信: xbx1717

本代码仅供个人学习使用，未经授权不得复制、修改或用于商业用途。

Author: 邢不行
"""
import pandas as pd
import numpy as np

from core.data_center import calculate_extended_line_all


fin_cols = []
ov_cols = ['大户资金买入额', '大户资金卖出额', '散户资金买入额', '散户资金卖出额', '中户资金买入额', '中户资金卖出额',
           '机构资金买入额', '机构资金卖出额']

extra_data = {'rzrq-stock':['融资余额', '融券余量', '融资融券余额',
                        '融券余额', '融券卖出量', '融资融券余额差值', '融资买入额', '融资余额占比', '融资偿还额',
                        '融资净买入额', '融券偿还量', '融券净卖出量']}

def add_factor(df: pd.DataFrame, param=None, **kwargs) -> pd.DataFrame:
    """
    因子计算主函数，支持根据多个关键点构建趋势线并生成信号

    :param df: 输入的行情数据
    :param param: 参数字典，包含 n（跌停窗口） 和 k（趋势线窗口）
    :param kwargs: 其他参数，如 col_name
    :return: 包含因子信号和趋势线的 DataFrame
    """

    # ======================== 参数处理 ===========================
    col_name = kwargs['col_name']
    # n = int(param.get('n', 5))  # 跌停窗口大小
    # k = int(param.get('k', 3))  # 用于趋势线的关键点数量

    # ======================== 计算基础指标 =======================
    df['是否跌停'] = (df['收盘价'] == df['跌停价']).astype(int)
    df['换手率'] = df['成交额'] / df['流通市值']

    df['融资买入额占比'] = df['融资买入额'] / df['成交额']

    # 原新高条件计算
    df['散户卖出占比'] = df['散户资金卖出额'] * 10000 / df['成交额']

    df['year_high_ratio'] = df.groupby(df['交易日期'].dt.year)['融资买入额占比'].cummin()
    #
    df['is_support'] = (df['融资买入额占比'] <= df['year_high_ratio'])

    df['year_high_ratio_year'] = df.groupby(df['交易日期'].dt.year)['散户卖出占比'].cummax()  # 滚动年内新高
    # df.groupby(df['交易日期'].dt.year)['散户卖出占比'].transform(lambda x: x.expanding().max())
    # 新高条件判断（需同时满足当前值=新高值）
    df['is_support1'] = (df['散户卖出占比'] >= df['year_high_ratio_year'])


    # 计算基准价格(用于百分比计算)
    df['base_price'] = df['收盘价']

    # 计算上影线长度和百分比
    df['lower_shadow'] = np.minimum(df['收盘价'], df['开盘价']) - df['最低价']
    df['lower_shadow_pct'] = df['lower_shadow'] / df['base_price'] * 100

    # 年内最低换手率
    df['年内最低换手率'] = df.groupby(df['交易日期'].dt.year)['换手率'].transform(
        lambda x: x.expanding().min()
    )

    # 标记关键点：跌停日 or 换手率年内最低
    df['is_support1']= (df['是否跌停'] == 0) | (df['换手率'] == df['年内最低换手率'])| (2 < df['lower_shadow_pct']) | (df['is_support1'] == 1) |  (df['is_support'] == 1)

    result = calculate_extended_line_all(df, condition_series=df['is_support1'])

    df[col_name] = result['extended_line']




    return df[[col_name]]  # 返回包含新增列的结果
