# noinspection PyUnusedLocal



import pandas as pd

# from tools.utils.tfunctions import double_factor_grouping

fin_cols = []  # 财务因子列


def add_factor(df: pd.DataFrame, param=None, **kwargs) -> pd.DataFrame:
    """
    计算每年前3个月的累计涨跌幅作为因子值。

    :param df: 包含单只股票的K线数据，必须包括'收盘价_复权'和'交易日期'列。
    :param param: 无实际用途，保留兼容性。
    :param kwargs: 其他关键字参数，包含：
        - col_name: 新因子列名。
    :return: pd.DataFrame，包含新因子列。
    """

    # 从额外参数中获取因子名称
    col_name = kwargs['col_name']

    # n = int(param)
    # m = int(param[1])
    # end = param[1]
    # 提取年月字段，用于按月分组
    df['年月'] =  df['交易日期'].dt.year

    # 计算每月第一个交易日的开盘价
    df['年初开盘价'] = df.groupby('年月')['开盘价_复权'].transform('first')
    # # 计算每个股票在每一年月内的累计交易日数量
    # df['月内累计交易日'] = df.groupby(['年月']).cumcount() + 1

    # df['比较天数'] = n

    # adjusted_n = max(n, 1)

    # print(df[['交易日期','年内累计交易日']])

    # df.loc[df['月内累计交易日'] < df['比较天数'], f'月度前{n}日收益率'] = df.groupby(df['年月'])['收盘价_复权'].transform(lambda x: x.pct_change(2))
    # df[f'月度前{n}日收益率'] = df.groupby(df['年月'])['收盘价_复权'].transform(lambda x: x.pct_change(adjusted_n))

    # 计算月度累计收益：当前收盘价 / 月初开盘价 - 1
    df[f'月度收益率'] = df['收盘价_复权'] / df['年初开盘价'] - 1
    # df[col_name] = df[f'月度前{n}日收益率']


    df[col_name] =  df[f'月度收益率']



    return df[[col_name]]
